import SwiftUI

/// واجهة إعدادات ThePornDB
struct ThePornDBSettingsView: View {
    @State private var apiKey: String
    @State private var performerLimit: String
    @State private var sceneLimit: String
    @State private var filterByYear: Bool
    @State private var year: String
    @State private var imageQuality: ThePornDBSettings.ImageQuality
    
    @Environment(\.dismiss) private var dismiss
    
    init() {
        _apiKey = State(initialValue: ThePornDBSettings.apiKey)
        _performerLimit = State(initialValue: String(ThePornDBSettings.PerformerSearch.defaultLimit))
        _sceneLimit = State(initialValue: String(ThePornDBSettings.SceneSearch.defaultLimit))
        _filterByYear = State(initialValue: ThePornDBSettings.SceneSearch.filterByYear)
        _year = State(initialValue: String(ThePornDBSettings.SceneSearch.year))
        _imageQuality = State(initialValue: ThePornDBSettings.PerformerSearch.imageQuality)
    }
    
    var body: some View {
        NavigationStack {
            Form {
                Section("مفتاح API") {
                    SecureField("مفتاح ThePornDB API", text: $apiKey)
                        .textContentType(.password)
                    
                    Text("احصل على مفتاح API من: https://theporndb.net/api")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Section("إعدادات البحث عن الممثلات") {
                    HStack {
                        Text("عدد النتائج")
                        Spacer()
                        TextField("20", text: $performerLimit)
                            .textFieldStyle(.roundedBorder)
                            .frame(width: 60)
                            .multilineTextAlignment(.center)
                    }
                    
                    Picker("جودة الصور", selection: $imageQuality) {
                        Text("منخفضة").tag(ThePornDBSettings.ImageQuality.low)
                        Text("متوسطة").tag(ThePornDBSettings.ImageQuality.medium)
                        Text("عالية").tag(ThePornDBSettings.ImageQuality.high)
                    }
                }
                
                Section("إعدادات البحث عن المشاهد") {
                    HStack {
                        Text("عدد النتائج")
                        Spacer()
                        TextField("20", text: $sceneLimit)
                            .textFieldStyle(.roundedBorder)
                            .frame(width: 60)
                            .multilineTextAlignment(.center)
                    }
                    
                    Toggle("فلترة حسب السنة", isOn: $filterByYear)
                    
                    if filterByYear {
                        HStack {
                            Text("السنة")
                            Spacer()
                            TextField("2024", text: $year)
                                .textFieldStyle(.roundedBorder)
                                .frame(width: 80)
                                .multilineTextAlignment(.center)
                        }
                    }
                }
            }
            .navigationTitle("إعدادات ThePornDB")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("إلغاء") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("حفظ") {
                        saveSettings()
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func saveSettings() {
        ThePornDBSettings.apiKey = apiKey
        ThePornDBSettings.PerformerSearch.defaultLimit = Int(performerLimit) ?? 20
        ThePornDBSettings.SceneSearch.defaultLimit = Int(sceneLimit) ?? 20
        ThePornDBSettings.SceneSearch.filterByYear = filterByYear
        ThePornDBSettings.SceneSearch.year = Int(year) ?? 0
        ThePornDBSettings.PerformerSearch.imageQuality = imageQuality
    }
}
