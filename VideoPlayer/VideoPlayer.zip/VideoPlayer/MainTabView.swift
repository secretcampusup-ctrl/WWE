import SwiftUI
import UIKit
import Kingfisher

/// Root shell: Library, Recent, Offcloud, Media
struct MainTabView: View {
    @StateObject private var vm = AppViewModel()
    @State private var selectedTab = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            ContentView(vm: vm, isActive: selectedTab == 0)
                .tabItem {
                    Label("Library", systemImage: "play.rectangle.on.rectangle")
                }
                .tag(0)

            RecentVideosView(vm: vm, isActive: selectedTab == 1)
                .tabItem {
                    Label("Recent", systemImage: "clock.fill")
                }
                .tag(1)

            OffcloudView(vm: vm)
                .tabItem {
                    Label("Offcloud", systemImage: "cloud.fill")
                }
                .tag(2)

            PikPakWebDAVView(vm: vm, isActive: selectedTab == 3)
                .tabItem {
                    Label("PikPak", systemImage: "externaldrive.connected.to.line.below")
                }
                .tag(3)

            MediaView(vm: vm)
                .tabItem {
                    Label("Media", systemImage: "dot.radiowaves.left.and.right")
                }
                .tag(4)
        }
        .transaction { $0.animation = nil }
        .tint(.green)
        .preferredColorScheme(.dark)
    }
}

// MARK: - Shared visual tokens

enum AppTheme {
    static let bg = Color(red: 0.04, green: 0.04, blue: 0.05)
    static let card = Color(red: 0.10, green: 0.10, blue: 0.12)
    static let cardElevated = Color(red: 0.13, green: 0.13, blue: 0.15)
    static let accent = Color.green
    static let accentDeep = Color(red: 0.0, green: 0.55, blue: 0.25)
    static let muted = Color.white.opacity(0.45)
    static let mutedDeep = Color.white.opacity(0.38)

    static let titleGradient = LinearGradient(
        colors: [
            Color(red: 0.85, green: 0.98, blue: 0.92),
            Color(red: 0.55, green: 0.95, blue: 0.75)
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    static let accentGradient = LinearGradient(
        colors: [
            Color.green,
            Color(red: 0.15, green: 0.75, blue: 0.40)
        ],
        startPoint: .leading,
        endPoint: .trailing
    )
}

// MARK: - Media Models

enum MediaCategory: String, CaseIterable, Identifiable, Codable {
    case allCategories = "All Categories"
    case p1080 = "1080p"
    case p2160 = "2160p"
    case pack = "Pack"

    var id: String { rawValue }

    var shortLabel: String {
        switch self {
        case .allCategories: return "All"
        case .p1080: return "1080p"
        case .p2160: return "2160p"
        case .pack: return "Pack"
        }
    }

    var icon: String {
        switch self {
        case .allCategories: return "square.grid.2x2"
        case .p1080: return "tv"
        case .p2160: return "4k.tv"
        case .pack: return "shippingbox"
        }
    }
}

struct MediaFeedSettings: Codable, Equatable {
    var urls: [String: String] = [:]

    func url(for category: MediaCategory) -> String {
        urls[category.rawValue] ?? ""
    }

    mutating func setURL(_ value: String, for category: MediaCategory) {
        urls[category.rawValue] = value
    }

    var hasAnyFeed: Bool {
        urls.values.contains { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    }
}

enum MediaFeedStore {
    private static let key = "media_rss_feed_settings_v1"

    static func load() -> MediaFeedSettings {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode(MediaFeedSettings.self, from: data) else {
            return MediaFeedSettings()
        }
        return decoded
    }

    static func save(_ settings: MediaFeedSettings) {
        guard let data = try? JSONEncoder().encode(settings) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}

struct MediaItem: Identifiable, Hashable {
    let id = UUID()
    let rawTitle: String
    /// Best URL for actions (magnet / torrent / stream)
    let link: String
    /// HTTP page to scrape for images + metadata (details page)
    let pageURL: String?
    let pubDate: String?
    let summary: String?
    let sizeBytes: Int64?

    var displayTitle: String {
        VideoTitleFormatter.title(from: rawTitle)
    }

    var resolutionLabel: String? {
        VideoTitleFormatter.resolution(from: rawTitle)
    }

    var seasonEpisodeLabel: String? {
        VideoTitleFormatter.seasonEpisode(from: rawTitle)
    }

    var sizeLabel: String? {
        if let sizeBytes, sizeBytes > 0 {
            let formatter = ByteCountFormatter()
            formatter.allowedUnits = [.useMB, .useGB]
            formatter.countStyle = .file
            return formatter.string(fromByteCount: sizeBytes)
        }
        return MediaMetadataParser.size(from: combinedText)
    }

    var relativeDateLabel: String? {
        guard let pubDate, let date = MediaItem.parseDate(pubDate) else { return nil }
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter.localizedString(for: date, relativeTo: Date())
    }

    var isMagnetOrTorrent: Bool {
        let lower = link.lowercased()
        return lower.hasPrefix("magnet:") || lower.hasSuffix(".torrent")
    }

    /// URL used to fetch images/metadata
    var scrapeURL: String? {
        if let pageURL, let u = URL(string: pageURL), let s = u.scheme?.lowercased(), s == "http" || s == "https" {
            return pageURL
        }
        if let u = URL(string: link), let s = u.scheme?.lowercased(), s == "http" || s == "https" {
            return link
        }
        if let summary {
            return MediaPageScraper.firstDetailsURL(in: summary)?.absoluteString
        }
        return nil
    }

    private var combinedText: String {
        [rawTitle, summary ?? ""].joined(separator: "\n")
    }

    var seedCountLabel: String? { MediaMetadataParser.seeds(from: combinedText) }
    var collectionLabel: String? { MediaMetadataParser.collection(from: combinedText) }
    var videoFormatLabel: String? { MediaMetadataParser.videoFormat(from: combinedText) }
    var frameRateLabel: String? { MediaMetadataParser.frameRate(from: combinedText) }
    var resolutionDetailLabel: String? { MediaMetadataParser.resolutionDetail(from: combinedText) }
    var bitrateLabel: String? { MediaMetadataParser.bitrate(from: combinedText) }

    private static let dateFormatters: [DateFormatter] = {
        let patterns = [
            "EEE, dd MMM yyyy HH:mm:ss Z",
            "EEE, dd MMM yyyy HH:mm:ss zzz",
            "yyyy-MM-dd'T'HH:mm:ssZ",
            "yyyy-MM-dd'T'HH:mm:ss"
        ]
        return patterns.map { pattern in
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.dateFormat = pattern
            return formatter
        }
    }()

    static func parseDate(_ raw: String) -> Date? {
        for formatter in dateFormatters {
            if let date = formatter.date(from: raw) { return date }
        }
        return ISO8601DateFormatter().date(from: raw)
    }
}

// MARK: - Metadata parsing from title / description

enum MediaMetadataParser {
    static func seeds(from text: String) -> String? {
        let patterns = [
            #"(?i)(?:seeds?|seeders?)\s*[:=]?\s*(\d{1,6})"#,
            #"(?i)\[(\d{1,5})\s*/\s*\d{1,5}\]"#,
            #"(?i)(\d{1,5})\s*seed"#
        ]
        for p in patterns {
            if let m = firstGroup(p, in: text) { return m }
        }
        return nil
    }

    static func collection(from text: String) -> String? {
        let patterns = [
            #"(?i)(?:collection|pack|series|studio)\s*[:=]\s*([^\n|\[\]]{2,40})"#,
            #"(?i)\[(pack|collection)[^\]]{0,30}\]"#
        ]
        for p in patterns {
            if let m = firstGroup(p, in: text) {
                return m.trimmingCharacters(in: .whitespacesAndNewlines)
            }
        }
        return nil
    }

    static func videoFormat(from text: String) -> String? {
        let patterns = [
            #"(?i)\b(HEVC|H\.?265|H\.?264|AVC|AV1|VP9|x265|x264|ProRes|MPEG-?4)\b"#,
            #"(?i)\b(MKV|MP4|AVI|TS|M2TS|WEB-?DL|BluRay|BDRip|WEBRip)\b"#
        ]
        var found: [String] = []
        for p in patterns {
            if let m = firstGroup(p, in: text), !found.contains(where: { $0.caseInsensitiveCompare(m) == .orderedSame }) {
                found.append(m.uppercased().replacingOccurrences(of: "H.265", with: "H.265")
                    .replacingOccurrences(of: "H265", with: "H.265")
                    .replacingOccurrences(of: "H.264", with: "H.264")
                    .replacingOccurrences(of: "H264", with: "H.264"))
            }
        }
        return found.isEmpty ? nil : found.joined(separator: " · ")
    }

    static func frameRate(from text: String) -> String? {
        let patterns = [
            #"(?i)(\d{2}(?:\.\d{1,2})?)\s*fps"#,
            #"(?i)(\d{2})\s*p\b"#
        ]
        // Prefer explicit fps
        if let m = firstGroup(#"(?i)(\d{2}(?:\.\d{1,2})?)\s*fps"#, in: text) {
            return "\(m) fps"
        }
        return nil
    }

    static func resolutionDetail(from text: String) -> String? {
        if let regex = try? NSRegularExpression(pattern: #"(?i)(\d{3,4})\s*[x×]\s*(\d{3,4})"#),
           let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
           let r1 = Range(match.range(at: 1), in: text),
           let r2 = Range(match.range(at: 2), in: text) {
            return "\(text[r1])×\(text[r2])"
        }
        if text.range(of: #"(?i)2160p|4k|uhd"#, options: .regularExpression) != nil { return "3840×2160" }
        if text.range(of: #"(?i)1080p|fhd"#, options: .regularExpression) != nil { return "1920×1080" }
        if text.range(of: #"(?i)720p"#, options: .regularExpression) != nil { return "1280×720" }
        return nil
    }

    static func bitrate(from text: String) -> String? {
        if let m = firstGroup(#"(?i)(\d{1,5}(?:\.\d+)?)\s*(?:mbps|mbit)"#, in: text) {
            return "\(m) Mbps"
        }
        if let m = firstGroup(#"(?i)(\d{3,5})\s*kbps"#, in: text) {
            return "\(m) kbps"
        }
        return nil
    }

    static func size(from text: String) -> String? {
        if let regex = try? NSRegularExpression(pattern: #"(?i)(\d+(?:\.\d+)?)\s*(GiB|GB|MiB|MB)"#),
           let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
           let n = Range(match.range(at: 1), in: text),
           let u = Range(match.range(at: 2), in: text) {
            return "\(text[n]) \(text[u].uppercased())"
        }
        return nil
    }

    private static func firstGroup(_ pattern: String, in text: String) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              match.numberOfRanges > 1,
              let range = Range(match.range(at: 1), in: text) else { return nil }
        return String(text[range])
    }
}

// MARK: - Media RSS Service

enum MediaRSSError: LocalizedError {
    case missingFeedURL
    case invalidURL
    case badResponse(Int)
    case network(Error)
    case emptyFeed

    var errorDescription: String? {
        switch self {
        case .missingFeedURL:
            return "No RSS link is set for this category yet. Add one from Settings."
        case .invalidURL:
            return "That RSS link doesn't look valid."
        case .badResponse(let code):
            return "The feed server returned an error (\(code))."
        case .network(let error):
            return error.localizedDescription
        case .emptyFeed:
            return "No results in this feed."
        }
    }
}

enum MediaRSSQueryBuilder {
    static func buildURL(template: String, query: String) -> URL? {
        let trimmedTemplate = template.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedTemplate.isEmpty else { return nil }

        let trimmedQuery = query.trimmingCharacters(in: .whitespacesAndNewlines)
        let encodedQuery = trimmedQuery.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""

        if trimmedTemplate.contains("{query}") {
            let replaced = trimmedTemplate.replacingOccurrences(of: "{query}", with: encodedQuery)
            return URL(string: replaced)
        }

        guard !trimmedQuery.isEmpty else {
            return URL(string: trimmedTemplate)
        }

        let separator = trimmedTemplate.contains("?") ? "&" : "?"
        return URL(string: "\(trimmedTemplate)\(separator)search=\(encodedQuery)")
    }
}

enum MediaRSSService {
    static func fetch(feedTemplate: String, query: String) async throws -> [MediaItem] {
        let trimmed = feedTemplate.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw MediaRSSError.missingFeedURL }
        guard let url = MediaRSSQueryBuilder.buildURL(template: trimmed, query: query) else {
            throw MediaRSSError.invalidURL
        }

        var request = URLRequest(url: url)
        request.setValue("VideoPlayer/1.0 (RSS reader)", forHTTPHeaderField: "User-Agent")
        request.timeoutInterval = 20

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw MediaRSSError.network(error)
        }

        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            throw MediaRSSError.badResponse(http.statusCode)
        }

        let parser = RSSFeedParser()
        return parser.parse(data: data)
    }
}

final class RSSFeedParser: NSObject, XMLParserDelegate {
    private var items: [MediaItem] = []
    private var currentElement = ""
    private var insideItem = false
    private var title = ""
    private var link = ""
    private var enclosureURL = ""
    private var pubDate = ""
    private var itemDescription = ""
    private var enclosureLength: Int64?

    func parse(data: Data) -> [MediaItem] {
        items = []
        let parser = XMLParser(data: data)
        parser.delegate = self
        parser.parse()
        return items
    }

    func parser(
        _ parser: XMLParser,
        didStartElement elementName: String,
        namespaceURI: String?,
        qualifiedName qName: String?,
        attributes attributeDict: [String: String] = [:]
    ) {
        let name = elementName.lowercased()
        currentElement = name

        if name == "item" || name == "entry" {
            insideItem = true
            title = ""
            link = ""
            enclosureURL = ""
            pubDate = ""
            itemDescription = ""
            enclosureLength = nil
        }

        guard insideItem else { return }

        if name == "enclosure" {
            if let lengthString = attributeDict["length"] {
                enclosureLength = Int64(lengthString)
            }
            if let href = attributeDict["url"], !href.isEmpty {
                enclosureURL = href
            }
        }

        if name == "link", let href = attributeDict["href"], !href.isEmpty {
            link = href
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) {
        guard insideItem else { return }
        switch currentElement {
        case "title":
            title += string
        case "link":
            link += string
        case "pubdate", "published", "updated", "dc:date":
            pubDate += string
        case "description", "summary", "content":
            itemDescription += string
        default:
            break
        }
    }

    func parser(
        _ parser: XMLParser,
        didEndElement elementName: String,
        namespaceURI: String?,
        qualifiedName qName: String?
    ) {
        let name = elementName.lowercased()
        if name == "item" || name == "entry" {
            let cleanTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
            let cleanLink = link.trimmingCharacters(in: .whitespacesAndNewlines)
            let cleanEnclosure = enclosureURL.trimmingCharacters(in: .whitespacesAndNewlines)
            let summaryText = itemDescription.trimmingCharacters(in: .whitespacesAndNewlines)
            // Prefer magnet/torrent for action; keep http(s) as page for scraping
            let actionLink: String = {
                let e = cleanEnclosure.lowercased()
                if e.hasPrefix("magnet:") || e.hasSuffix(".torrent") { return cleanEnclosure }
                let l = cleanLink.lowercased()
                if l.hasPrefix("magnet:") || l.hasSuffix(".torrent") { return cleanLink }
                if !cleanEnclosure.isEmpty { return cleanEnclosure }
                return cleanLink
            }()
            let page: String? = {
                for candidate in [cleanLink, cleanEnclosure] {
                    let low = candidate.lowercased()
                    if low.hasPrefix("http://") || low.hasPrefix("https://") {
                        return candidate
                    }
                }
                if let found = MediaPageScraper.firstDetailsURL(in: summaryText)?.absoluteString {
                    return found
                }
                return nil
            }()
            if !cleanTitle.isEmpty && !actionLink.isEmpty {
                items.append(
                    MediaItem(
                        rawTitle: cleanTitle,
                        link: actionLink,
                        pageURL: page,
                        pubDate: pubDate.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                            ? nil : pubDate.trimmingCharacters(in: .whitespacesAndNewlines),
                        summary: summaryText.isEmpty ? nil : summaryText,
                        sizeBytes: enclosureLength
                    )
                )
            }
            insideItem = false
        }
        currentElement = ""
    }
}

// MARK: - Page scraper (images + torrent metadata)

struct MediaPageDetails {
    var imageURLs: [URL] = []
    var sizeLabel: String?
    var seedsLabel: String?
    var collectionLabel: String?
    var videoFormat: String?
    var frameRate: String?
    var resolution: String?
    var bitrate: String?
    var duration: String?
}

enum MediaPageScraper {
    static func load(for pageURLString: String) async -> MediaPageDetails {
        guard let pageURL = URL(string: pageURLString),
              let scheme = pageURL.scheme?.lowercased(),
              scheme == "http" || scheme == "https" else { return MediaPageDetails() }

        var request = URLRequest(url: pageURL)
        request.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue("text/html,application/xhtml+xml", forHTTPHeaderField: "Accept")
        request.timeoutInterval = 20

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode),
                  let html = String(data: data, encoding: .utf8)
                    ?? String(data: data, encoding: .isoLatin1) else {
                return MediaPageDetails()
            }
            return parse(html: html, baseURL: pageURL)
        } catch {
            return MediaPageDetails()
        }
    }

    static func parse(html: String, baseURL: URL?) -> MediaPageDetails {
        var details = MediaPageDetails()
        let plain = html
            .replacingOccurrences(of: "<br\\s*/?>", with: "\n", options: .regularExpression)
            .replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
            .replacingOccurrences(of: "&nbsp;", with: " ")
            .replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)

        // Size : 10.23 GB
        details.sizeLabel = firstMatch(#"(?i)Size\s*:\s*(\d+(?:\.\d+)?\s*(?:GiB|GB|MiB|MB))"#, in: plain)
            ?? firstMatch(#"(?i)File size\.+:\s*(\d+(?:\.\d+)?\s*(?:GiB|GB|MiB|MB))"#, in: plain)

        // Peers : 1 seeders , 0 leechers
        if let seeds = firstMatch(#"(?i)(\d+)\s*seeders?"#, in: plain) {
            details.seedsLabel = seeds
        }

        // Collection : HotMilfsFuck
        details.collectionLabel = firstMatch(#"(?i)Collection\s*:\s*([A-Za-z0-9][A-Za-z0-9 ._-]{1,40})"#, in: plain)

        // Mediainfo block
        details.frameRate = firstMatch(#"(?i)Frame rate\.+:\s*([\d.]+\s*FPS)"#, in: plain)
        details.resolution = firstMatch(#"(?i)Resolution\.+:\s*(\d{3,4}\s*[x×]\s*\d{3,4})"#, in: plain)
            ?? firstMatch(#"(?i)Resolution\.+:\s*(\d{3,4}x\d{3,4})"#, in: plain)
        details.bitrate = firstMatch(#"(?i)Bitrate\.+:\s*([\d.]+\s*(?:Mb/s|Mbps|kb/s|kbps))"#, in: plain)
        details.duration = firstMatch(#"(?i)Duration\.+:\s*([^\n]{3,30})"#, in: plain)

        // Video format from mediainfo (prefer codec over container)
        if let format = firstMatch(#"(?i)Video\s*:\s*Format\.+:\s*([A-Za-z0-9.]+)"#, in: plain)
            ?? firstMatch(#"(?i)Format\.+:\s*(AVC|HEVC|AV1|VP9|x264|x265|H\.?264|H\.?265)"#, in: plain) {
            details.videoFormat = format.uppercased()
        }

        details.imageURLs = extractImageURLs(from: html, baseURL: baseURL)
        return details
    }

    static func extractImageURLs(from html: String, baseURL: URL?) -> [URL] {
        var results: [URL] = []
        var seen = Set<String>()

        func append(_ rawIn: String) {
            var raw = rawIn
                .replacingOccurrences(of: "&amp;", with: "&")
                .trimmingCharacters(in: .whitespacesAndNewlines)
            if raw.hasPrefix("//") { raw = "https:" + raw }
            // drop viewer wrappers
            if raw.lowercased().hasSuffix(".html") {
                raw = String(raw.dropLast(5))
            }
            // Always prefer the highest known working resolution on these CDNs
            // imgtraffic: /1s/ (tiny thumb) / z-1/ (viewer) → /1/ (full)
            if raw.contains("imgtraffic.com/1s/") {
                raw = raw.replacingOccurrences(of: "imgtraffic.com/1s/", with: "imgtraffic.com/1/")
            }
            if raw.contains("imgtraffic.com/z-1/") {
                raw = raw.replacingOccurrences(of: "imgtraffic.com/z-1/", with: "imgtraffic.com/1/")
            }
            // imgxclub: /ps/ similar thumbs are low-res; keep /p/ posters as-is
            if raw.contains("imgxclub.com/ps/") {
                // similar-torrent strip only — skip, not main screenshots
                return
            }
            if raw.contains("imgtraffic.com/i/") { return }

            guard let url = URL(string: raw) ?? (baseURL.flatMap { URL(string: raw, relativeTo: $0)?.absoluteURL }),
                  let scheme = url.scheme?.lowercased(),
                  scheme == "http" || scheme == "https" else { return }

            let key = url.absoluteString
            guard seen.insert(key).inserted else { return }
            let lower = key.lowercased()

            if lower.contains("logo") || lower.contains("xclogo") || lower.contains("favicon")
                || lower.contains("sprite") || lower.hasSuffix(".svg") || lower.contains("apple-touch")
                || lower.contains("android-chrome") {
                return
            }
            // only real image files
            guard lower.contains(".jpg") || lower.contains(".jpeg") || lower.contains(".png") || lower.contains(".webp") else {
                return
            }
            results.append(url)
        }

        // 1) All <img src="...">
        if let regex = try? NSRegularExpression(pattern: #"<img[^>]+src=["']([^"']+)["']"#, options: [.caseInsensitive]) {
            let range = NSRange(html.startIndex..., in: html)
            for match in regex.matches(in: html, range: range) {
                guard match.numberOfRanges > 1, let r = Range(match.range(at: 1), in: html) else { continue }
                append(String(html[r]))
            }
        }

        // 2) og:image
        if let regex = try? NSRegularExpression(pattern: #"<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']"#, options: [.caseInsensitive]) {
            let range = NSRange(html.startIndex..., in: html)
            for match in regex.matches(in: html, range: range) {
                guard match.numberOfRanges > 1, let r = Range(match.range(at: 1), in: html) else { continue }
                append(String(html[r]))
            }
        }

        // 3) Any imgxclub / imgtraffic URL in the HTML
        if let regex = try? NSRegularExpression(pattern: #"https?://(?:imgxclub\.com|imgtraffic\.com)/[^\s"'<>]+"#, options: [.caseInsensitive]) {
            let range = NSRange(html.startIndex..., in: html)
            for match in regex.matches(in: html, range: range) {
                guard let r = Range(match.range, in: html) else { continue }
                append(String(html[r]))
            }
        }

        // Prefer poster + screenshots; hide similar-torrent /ps/ when screenshots exist
        let prioritized = results.sorted { a, b in
            func rank(_ u: URL) -> Int {
                let s = u.absoluteString.lowercased()
                if s.contains("imgxclub.com/p/20") { return 0 }
                if s.contains("imgtraffic.com/1s/") { return 1 }
                if s.contains("imgxclub.com/p/") { return 2 }
                if s.contains("/ps/") { return 9 }
                return 5
            }
            return rank(a) < rank(b)
        }
        let hasShots = prioritized.contains { let s = $0.absoluteString.lowercased(); return s.contains("imgtraffic.com/1/") || s.contains("imgtraffic.com/1s/") }
        let filtered = hasShots ? prioritized.filter { !$0.absoluteString.lowercased().contains("/ps/") } : prioritized
        // Final pass: never hand UI a thumbnail URL when a full URL is known
        let maxQuality = filtered.map { url -> URL in
            var s = url.absoluteString
            s = s.replacingOccurrences(of: "imgtraffic.com/1s/", with: "imgtraffic.com/1/")
            s = s.replacingOccurrences(of: "imgtraffic.com/z-1/", with: "imgtraffic.com/1/")
            return URL(string: s) ?? url
        }
        // Dedupe after rewrite
        var final: [URL] = []
        var seenFinal = Set<String>()
        for u in maxQuality {
            let key = u.absoluteString
            guard seenFinal.insert(key).inserted else { continue }
            final.append(u)
        }
        return Array(final.prefix(24))
    }


    /// Magnet-only RSS: search the tracker by title and pick the first details page.
    static func resolveDetailsPage(forTitle title: String, preferredHosts: [String] = ["xxxclub.me", "xxxclub.to", "xxxclub.cc"]) async -> URL? {
        let query = title
            .replacingOccurrences(of: #"\[.*?\]"#, with: " ", options: .regularExpression)
            .replacingOccurrences(of: #"[^\w\s.\-]"#, with: " ", options: .regularExpression)
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard query.count >= 6 else { return nil }

        let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? query

        for host in preferredHosts {
            let searchURLString = "https://\(host)/torrents/search/all/\(encoded)"
            guard let searchURL = URL(string: searchURLString) else { continue }

            var request = URLRequest(url: searchURL)
            request.setValue(
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
                forHTTPHeaderField: "User-Agent"
            )
            request.setValue("https://\(host)/", forHTTPHeaderField: "Referer")
            request.timeoutInterval = 18

            guard let (data, response) = try? await URLSession.shared.data(for: request),
                  let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode),
                  let html = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1)
            else { continue }

            // Prefer a details link whose surrounding text resembles the title
            if let url = bestDetailsURL(in: html, host: host, title: title) {
                return url
            }
        }
        return nil
    }

    private static func bestDetailsURL(in html: String, host: String, title: String) -> URL? {
        let pattern = #"/torrents/details/~-?[0-9]+"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
        let range = NSRange(html.startIndex..., in: html)
        let matches = regex.matches(in: html, range: range)
        guard !matches.isEmpty else { return nil }

        // Token overlap scoring against nearby text
        let tokens = Set(
            title.lowercased()
                .components(separatedBy: CharacterSet.alphanumerics.inverted)
                .filter { $0.count > 2 }
        )

        var best: (score: Int, path: String)?
        for match in matches.prefix(25) {
            guard let r = Range(match.range, in: html) else { continue }
            let path = String(html[r])
            // window around match
            let start = html.index(r.lowerBound, offsetBy: -120, limitedBy: html.startIndex) ?? html.startIndex
            let end = html.index(r.upperBound, offsetBy: 120, limitedBy: html.endIndex) ?? html.endIndex
            let window = html[start..<end].lowercased()
            let score = tokens.reduce(0) { partial, token in
                partial + (window.contains(token) ? 1 : 0)
            }
            if best == nil || score > best!.score {
                best = (score, path)
            }
        }

        guard let path = best?.path else { return nil }
        return URL(string: "https://\(host)\(path)")
    }


        static func firstDetailsURL(in text: String) -> URL? {
        let patterns = [
            #"https?://[^\\s"'<>]+/torrents/details/[^\\s"'<>]+"#,
            #"https?://xxxclub\\.me/[^\\s"'<>]+"#
        ]
        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
                  let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
                  let range = Range(match.range, in: text) else { continue }
            var raw = String(text[range])
            raw = raw.trimmingCharacters(in: CharacterSet(charactersIn: "\"')]}>,."))
            if let url = URL(string: raw) { return url }
        }
        return nil
    }

    private static func firstMatch(_ pattern: String, in text: String) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              match.numberOfRanges > 1,
              let range = Range(match.range(at: 1), in: text) else { return nil }
        return String(text[range]).trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

// MARK: - Palette

enum MediaPalette {
    static let bg = Color(red: 0x09 / 255, green: 0x0B / 255, blue: 0x0E / 255)
    static let card = Color(red: 0x14 / 255, green: 0x16 / 255, blue: 0x1C / 255)
    static let accent = Color(red: 0.18, green: 0.83, blue: 0.75)
    static let muted = Color.white.opacity(0.5)
    static let border = Color.white.opacity(0.08)
}

// MARK: - Media Settings

struct MediaSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var settings: MediaFeedSettings
    @FocusState private var focusedField: MediaCategory?
    let onSave: (MediaFeedSettings) -> Void

    init(settings: MediaFeedSettings, onSave: @escaping (MediaFeedSettings) -> Void) {
        _settings = State(initialValue: settings)
        self.onSave = onSave
    }

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Add the RSS link for each category below. Tap a filter on the Media screen to search it directly.")
                        .font(.system(size: 13))
                        .foregroundColor(.white.opacity(0.55))
                        .fixedSize(horizontal: false, vertical: true)

                    ForEach(MediaCategory.allCases) { category in
                        feedField(for: category)
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        Label("Tip", systemImage: "lightbulb")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(MediaPalette.accent)
                        Text("If your tracker's RSS uses a search parameter, include a {query} placeholder, e.g. https://example.com/rss?search={query}&cat=1080p. Without a placeholder, the search text is appended automatically.")
                            .font(.system(size: 12))
                            .foregroundColor(.white.opacity(0.5))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(14)
                    .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14))
                }
                .padding(16)
            }
            .background(MediaPalette.bg.ignoresSafeArea())
            .navigationTitle("RSS Feeds")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                        .foregroundColor(.white.opacity(0.7))
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        onSave(settings)
                        dismiss()
                    }
                    .fontWeight(.semibold)
                    .foregroundColor(MediaPalette.accent)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    @ViewBuilder
    private func feedField(for category: MediaCategory) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(category.rawValue, systemImage: category.icon)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.white)

            TextField(
                "https://example.com/rss?search={query}",
                text: Binding(
                    get: { settings.url(for: category) },
                    set: { settings.setURL($0, for: category) }
                )
            )
            .focused($focusedField, equals: category)
            .textFieldStyle(.plain)
            .foregroundColor(.white)
            .keyboardType(.URL)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .padding(12)
            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12))
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(
                        focusedField == category ? MediaPalette.accent.opacity(0.7) : Color.white.opacity(0.08),
                        lineWidth: 1
                    )
            )
        }
    }
}

// MARK: - Detail page for a result

struct MediaItemDetailView: View {
    let item: MediaItem
    let onPlayOrSend: () -> Void
    let isSending: Bool
    let isSent: Bool

    @Environment(\.dismiss) private var dismiss
    @State private var imageURLs: [URL] = []
    @State private var isLoadingImages = true
    @State private var copied = false
    @State private var selectedImageURL: URL?
    @State private var scraped = MediaPageDetails()

    private let columns = [
        GridItem(.flexible(), spacing: 10),
        GridItem(.flexible(), spacing: 10)
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    titleBlock
                    metaGrid
                    videoInfoSection
                    imagesSection
                    actionsBar
                }
                .padding(16)
                .padding(.bottom, 28)
            }
            .background(MediaPalette.bg.ignoresSafeArea())
            .navigationTitle("Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                        .foregroundColor(MediaPalette.accent)
                }
            }
        }
        .preferredColorScheme(.dark)
        .task {
            await loadImages()
        }
        .fullScreenCover(item: Binding(
            get: {
                guard let url = selectedImageURL else { return nil as IdentifiedURL? }
                let idx = imageURLs.firstIndex(of: url) ?? 0
                return IdentifiedURL(url: url, index: idx)
            },
            set: { selectedImageURL = $0?.url }
        )) { wrapped in
            MediaImageGallery(
                urls: imageURLs.isEmpty ? [wrapped.url] : imageURLs,
                startIndex: wrapped.index
            ) {
                selectedImageURL = nil
            }
        }
    }

    private var titleBlock: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(item.displayTitle)
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.white)
                .fixedSize(horizontal: false, vertical: true)

            if let raw = Optional(item.rawTitle), raw != item.displayTitle {
                Text(raw)
                    .font(.system(size: 12))
                    .foregroundColor(MediaPalette.muted)
                    .lineLimit(3)
            }
        }
    }

    private var metaGrid: some View {
        LazyVGrid(columns: [
            GridItem(.flexible(), spacing: 10),
            GridItem(.flexible(), spacing: 10)
        ], spacing: 10) {
            metaCard(icon: "internaldrive", label: "Size", value: scraped.sizeLabel ?? item.sizeLabel ?? "—")
            metaCard(icon: "calendar", label: "Date", value: item.relativeDateLabel ?? formattedPubDate ?? "—")
            metaCard(icon: "arrow.up.circle", label: "Seeds", value: scraped.seedsLabel ?? item.seedCountLabel ?? "—")
            metaCard(icon: "square.stack.3d.up", label: "Collection", value: scraped.collectionLabel ?? item.collectionLabel ?? "—")
        }
    }

    private var videoInfoSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Video")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.white.opacity(0.7))

            VStack(spacing: 0) {
                infoRow(title: "Format", value: scraped.videoFormat ?? item.videoFormatLabel ?? "—")
                Divider().background(Color.white.opacity(0.06))
                infoRow(title: "Resolution", value: scraped.resolution ?? item.resolutionDetailLabel ?? item.resolutionLabel ?? "—")
                Divider().background(Color.white.opacity(0.06))
                infoRow(title: "Frame rate", value: scraped.frameRate ?? item.frameRateLabel ?? "—")
                Divider().background(Color.white.opacity(0.06))
                infoRow(title: "Bitrate", value: scraped.bitrate ?? item.bitrateLabel ?? "—")
            }
            .background(MediaPalette.card, in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(MediaPalette.border, lineWidth: 1))
        }
    }

    private var imagesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Images")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white.opacity(0.7))
                Spacer()
                if isLoadingImages {
                    ProgressView().controlSize(.small).tint(MediaPalette.accent)
                } else {
                    Text("\(imageURLs.count)")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(MediaPalette.muted)
                }
            }

            if isLoadingImages {
                RoundedRectangle(cornerRadius: 16)
                    .fill(MediaPalette.card)
                    .frame(height: 160)
                    .overlay(ProgressView().tint(MediaPalette.accent))
            } else if imageURLs.isEmpty {
                RoundedRectangle(cornerRadius: 16)
                    .fill(MediaPalette.card)
                    .frame(height: 120)
                    .overlay(
                        VStack(spacing: 8) {
                            Image(systemName: "photo.on.rectangle.angled")
                                .font(.system(size: 28))
                                .foregroundColor(MediaPalette.muted)
                            Text("No images found on this page")
                                .font(.system(size: 13))
                                .foregroundColor(MediaPalette.muted)
                        }
                    )
            } else {
                LazyVGrid(columns: columns, spacing: 10) {
                    ForEach(imageURLs, id: \.absoluteString) { url in
                        Button {
                            selectedImageURL = url
                        } label: {
                            Color.clear
                                .frame(maxWidth: .infinity)
                                .frame(height: 150)
                                .overlay {
                                    MediaRemoteImage(url: url)
                                        .scaledToFill()
                                }
                                .clipped()
                                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                                .contentShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                                        .stroke(MediaPalette.border, lineWidth: 1)
                                )
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private var actionsBar: some View {
        VStack(spacing: 12) {
            Button {
                onPlayOrSend()
            } label: {
                HStack(spacing: 8) {
                    if isSending {
                        ProgressView().tint(.black)
                    } else if isSent {
                        Image(systemName: "checkmark.circle.fill")
                    } else {
                        Image(systemName: item.isMagnetOrTorrent ? "arrow.down.circle.fill" : "play.fill")
                    }
                    Text(primaryLabel)
                        .font(.system(size: 16, weight: .semibold))
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(isSent ? Color.white.opacity(0.18) : MediaPalette.accent, in: Capsule())
                .foregroundColor(isSent ? .white : .black)
            }
            .disabled(isSending)
            .buttonStyle(.plain)

            HStack(spacing: 12) {
                Button {
                    UIPasteboard.general.string = item.link
                    withAnimation { copied = true }
                    Task {
                        try? await Task.sleep(nanoseconds: 1_600_000_000)
                        withAnimation { copied = false }
                    }
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: copied ? "checkmark" : "doc.on.doc.fill")
                        Text(copied ? "Copied" : "Copy link")
                            .font(.system(size: 15, weight: .semibold))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
                    .background(
                        copied ? MediaPalette.accent.opacity(0.25) : Color.white.opacity(0.08),
                        in: Capsule()
                    )
                    .overlay(Capsule().stroke(MediaPalette.border, lineWidth: 1))
                    .foregroundColor(copied ? MediaPalette.accent : .white)
                }
                .buttonStyle(.plain)

                Button {
                    if let url = URL(string: item.link) {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "safari")
                        Text("Open")
                            .font(.system(size: 15, weight: .semibold))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
                    .background(Color.white.opacity(0.08), in: Capsule())
                    .overlay(Capsule().stroke(MediaPalette.border, lineWidth: 1))
                    .foregroundColor(.white)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.top, 4)
    }

    private var primaryLabel: String {
        if isSending { return "Sending…" }
        if isSent { return "Sent to Offcloud" }
        return item.isMagnetOrTorrent ? "Send to Offcloud" : "Play"
    }


    private func firstHTTPURL(in text: String) -> URL? {
        let pattern = #"https?://[^\s"'<>]+/torrents/details/[^\s"'<>]+"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              let range = Range(match.range, in: text) else { return nil }
        return URL(string: String(text[range]))
    }

    private var formattedPubDate: String? {
        guard let pubDate = item.pubDate, let date = MediaItem.parseDate(pubDate) else { return nil }
        let f = DateFormatter()
        f.dateStyle = .medium
        f.timeStyle = .short
        return f.string(from: date)
    }

    private func metaCard(icon: String, label: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(MediaPalette.accent)
                Text(label)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(MediaPalette.muted)
            }
            Text(value)
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(.white)
                .lineLimit(2)
                .minimumScaleFactor(0.8)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(MediaPalette.card, in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(MediaPalette.border, lineWidth: 1))
    }

    private func infoRow(title: String, value: String) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 13))
                .foregroundColor(MediaPalette.muted)
            Spacer()
            Text(value)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.white)
                .multilineTextAlignment(.trailing)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
    }

    private func loadImages() async {
        isLoadingImages = true
        defer { isLoadingImages = false }

        var urls: [URL] = []

        // 1) RSS description may already include screenshots / metadata HTML
        if let summary = item.summary {
            let fromSummary = MediaPageScraper.parse(html: summary, baseURL: URL(string: item.scrapeURL ?? item.link))
            urls.append(contentsOf: fromSummary.imageURLs)
            mergeScraped(fromSummary)
        }

        // 2) Direct details page URL (from RSS link / enclosure / summary)
        var pageURL = item.scrapeURL

        // 3) Magnet-only feeds (xxxclub RSS): resolve details page by searching title
        if pageURL == nil {
            if let resolved = await MediaPageScraper.resolveDetailsPage(forTitle: item.rawTitle) {
                pageURL = resolved.absoluteString
            }
        }

        // 4) Fetch details page → size / seeds / collection / mediainfo / images
        if let pageURL {
            let page = await MediaPageScraper.load(for: pageURL)
            mergeScraped(page)
            for u in page.imageURLs where !urls.contains(u) {
                urls.append(u)
            }
        }

        imageURLs = Array(urls.prefix(30))
    }

    private func mergeScraped(_ page: MediaPageDetails) {
        var s = scraped
        if s.sizeLabel == nil { s.sizeLabel = page.sizeLabel }
        if s.seedsLabel == nil { s.seedsLabel = page.seedsLabel }
        if s.collectionLabel == nil { s.collectionLabel = page.collectionLabel }
        if s.videoFormat == nil { s.videoFormat = page.videoFormat }
        if s.frameRate == nil { s.frameRate = page.frameRate }
        if s.resolution == nil { s.resolution = page.resolution }
        if s.bitrate == nil { s.bitrate = page.bitrate }
        if s.duration == nil { s.duration = page.duration }
        scraped = s
    }
}

private struct IdentifiedURL: Identifiable {
    let url: URL
    var index: Int = 0
    var id: String { url.absoluteString }
}

private struct MediaImageRefererModifier: ImageDownloadRequestModifier {
    func modified(for request: URLRequest) -> URLRequest? {
        var req = request
        req.setValue("https://xxxclub.me/", forHTTPHeaderField: "Referer")
        req.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
            forHTTPHeaderField: "User-Agent"
        )
        return req
    }
}

private struct MediaRemoteImage: View {
    let url: URL
    private let modifier = MediaImageRefererModifier()

    var body: some View {
        KFImage(url)
            .requestModifier(modifier)
            .cacheOriginalImage()
            .backgroundDecode()
            .placeholder {
                ZStack {
                    MediaPalette.card
                    ProgressView().tint(MediaPalette.accent)
                }
            }
            .onFailureView {
                ZStack {
                    MediaPalette.card
                    Image(systemName: "photo")
                        .foregroundColor(MediaPalette.muted)
                }
            }
            .resizable()
            .scaledToFill()
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
            .clipped()
    }
}



private struct MediaImageGallery: View {
    let urls: [URL]
    let startIndex: Int
    let onClose: () -> Void

    @State private var index: Int

    init(urls: [URL], startIndex: Int, onClose: @escaping () -> Void) {
        self.urls = urls
        self.startIndex = startIndex
        self.onClose = onClose
        let safe = urls.isEmpty ? 0 : min(max(0, startIndex), urls.count - 1)
        _index = State(initialValue: safe)
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            TabView(selection: $index) {
                ForEach(Array(urls.enumerated()), id: \.offset) { i, url in
                    MediaZoomableImage(url: url)
                        .tag(i)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .automatic))
            .indexViewStyle(.page(backgroundDisplayMode: .always))

            VStack {
                HStack {
                    Text("\(index + 1) / \(max(urls.count, 1))")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.white.opacity(0.9))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.white.opacity(0.12), in: Capsule())
                    Spacer()
                    Button(action: onClose) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 30))
                            .foregroundStyle(.white.opacity(0.95), .white.opacity(0.25))
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                Spacer()
            }
        }
        .statusBarHidden(true)
    }
}

private struct MediaZoomableImage: View {
    let url: URL
    @State private var scale: CGFloat = 1
    @State private var lastScale: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    var body: some View {
        GeometryReader { geo in
            let size = geo.size
            KFImage(url)
                .requestModifier(MediaImageRefererModifier())
                .cacheOriginalImage()
                .backgroundDecode()
                .placeholder {
                    ProgressView()
                        .tint(.white)
                        .frame(width: size.width, height: size.height)
                }
                .resizable()
                .scaledToFit()
                .scaleEffect(scale)
                .offset(offset)
                .frame(width: size.width, height: size.height)
                .gesture(
                    MagnificationGesture()
                        .onChanged { value in
                            let next = lastScale * value
                            scale = min(max(next, 1), 4)
                        }
                        .onEnded { _ in
                            lastScale = scale
                            if scale < 1.05 {
                                withAnimation(.spring()) {
                                    scale = 1
                                    lastScale = 1
                                    offset = .zero
                                    lastOffset = .zero
                                }
                            }
                        }
                )
                .simultaneousGesture(
                    DragGesture()
                        .onChanged { value in
                            guard scale > 1.05 else { return }
                            offset = CGSize(
                                width: lastOffset.width + value.translation.width,
                                height: lastOffset.height + value.translation.height
                            )
                        }
                        .onEnded { _ in
                            lastOffset = offset
                        }
                )
                .onTapGesture(count: 2) {
                    withAnimation(.spring()) {
                        if scale > 1.2 {
                            scale = 1
                            lastScale = 1
                            offset = .zero
                            lastOffset = .zero
                        } else {
                            scale = 2.5
                            lastScale = 2.5
                        }
                    }
                }
        }
    }
}


// MARK: - Media View

struct MediaView: View {
    @ObservedObject var vm: AppViewModel

    @State private var searchText = ""
    @State private var selectedCategory: MediaCategory = .allCategories
    @State private var feedSettings = MediaFeedStore.load()

    @State private var items: [MediaItem] = []
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var hasSearched = false

    @State private var showSettings = false
    @State private var showPlayer = false
    @State private var toast: String?
    @State private var sendingItemID: MediaItem.ID?
    @State private var sentItemIDs: Set<MediaItem.ID> = []
    @State private var selectedDetailItem: MediaItem?
    @FocusState private var searchFocused: Bool

    private var currentFeedURL: String { feedSettings.url(for: selectedCategory) }

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                searchBar
                filterRow
                content
            }
            .background(MediaPalette.bg.ignoresSafeArea())
            .navigationTitle("Media")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showSettings = true
                    } label: {
                        Image(systemName: "gear")
                            .foregroundColor(.white)
                    }
                }
            }
            .sheet(isPresented: $showSettings) {
                MediaSettingsView(settings: feedSettings) { updated in
                    feedSettings = updated
                    MediaFeedStore.save(updated)
                }
            }
            .sheet(item: $selectedDetailItem) { item in
                MediaItemDetailView(
                    item: item,
                    onPlayOrSend: {
                        handlePrimaryAction(item)
                    },
                    isSending: sendingItemID == item.id,
                    isSent: sentItemIDs.contains(item.id)
                )
            }
            .fullScreenCover(isPresented: $showPlayer) {
                if let url = vm.nowPlayingURL, let file = vm.nowPlaying {
                    VideoPlayerView(
                        url: url,
                        title: file.name,
                        resumeAt: vm.nowPlayingResumeAt,
                        linkId: vm.nowPlayingLinkId,
                        httpHeaders: vm.nowPlayingHeaders
                    ) { seconds, duration, w, h in
                        vm.updatePlaybackProgress(
                            seconds: seconds,
                            duration: duration,
                            width: w,
                            height: h,
                            linkId: vm.nowPlayingLinkId,
                            streamURL: url
                        )
                    }
                }
            }
            .overlay(alignment: .bottom) {
                if let toast {
                    toastView(toast)
                        .padding(.bottom, 24)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var searchBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundColor(MediaPalette.muted)

            TextField("Search RSS...", text: $searchText)
                .textFieldStyle(.plain)
                .foregroundColor(.white)
                .focused($searchFocused)
                .submitLabel(.search)
                .onSubmit { runSearch() }

            if !searchText.isEmpty {
                Button {
                    searchText = ""
                    searchFocused = false
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(MediaPalette.muted)
                }
            }

            Button {
                searchFocused = false
                runSearch()
            } label: {
                Text("Search")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.black)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(MediaPalette.accent, in: Capsule())
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(MediaPalette.border, lineWidth: 1))
        .padding(.horizontal, 16)
        .padding(.top, 12)
        .padding(.bottom, 8)
    }

    private var filterRow: some View {
        HStack(spacing: 8) {
            ForEach(MediaCategory.allCases) { category in
                Button {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                        selectedCategory = category
                    }
                    runSearch()
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: category.icon)
                            .font(.system(size: 11, weight: .semibold))
                        Text(category.shortLabel)
                            .font(.system(size: 13, weight: .semibold))
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(
                        selectedCategory == category ? MediaPalette.accent : Color.white.opacity(0.06)
                    )
                    .foregroundColor(selectedCategory == category ? .black : .white)
                    .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 12)
    }

    @ViewBuilder
    private var content: some View {
        if isLoading {
            Spacer()
            ProgressView()
                .tint(MediaPalette.accent)
            Text("Loading feed…")
                .font(.system(size: 13))
                .foregroundColor(MediaPalette.muted)
                .padding(.top, 8)
            Spacer()
        } else if let errorMessage {
            emptyState(
                systemImage: "exclamationmark.triangle",
                title: "Couldn't load feed",
                subtitle: errorMessage,
                showsSettingsButton: currentFeedURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            )
        } else if !hasSearched {
            emptyState(
                systemImage: "dot.radiowaves.left.and.right",
                title: "Search your RSS feeds",
                subtitle: feedSettings.hasAnyFeed
                    ? "Pick a category and search, or leave the box empty to browse the latest items."
                    : "Add your RSS links from the gear icon above to get started.",
                showsSettingsButton: !feedSettings.hasAnyFeed
            )
        } else if items.isEmpty {
            emptyState(
                systemImage: "magnifyingglass",
                title: "No results",
                subtitle: "Nothing matched \"\(searchText)\" in \(selectedCategory.rawValue).",
                showsSettingsButton: false
            )
        } else {
            List {
                ForEach(items) { item in
                    itemRow(item)
                        .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .refreshable { await performSearch() }
        }
    }

    private func emptyState(systemImage: String, title: String, subtitle: String, showsSettingsButton: Bool) -> some View {
        VStack(spacing: 14) {
            Spacer()
            Image(systemName: systemImage)
                .font(.system(size: 46))
                .foregroundColor(MediaPalette.accent.opacity(0.85))
            Text(title)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.white)
            Text(subtitle)
                .font(.system(size: 13))
                .foregroundColor(MediaPalette.muted)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
            if showsSettingsButton {
                Button {
                    showSettings = true
                } label: {
                    Text("Add RSS Links")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.black)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(MediaPalette.accent, in: Capsule())
                }
                .padding(.top, 4)
            }
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func itemRow(_ item: MediaItem) -> some View {
        Button {
            selectedDetailItem = item
        } label: {
            VStack(alignment: .leading, spacing: 10) {
                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(item.displayTitle)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(.white)
                            .lineLimit(2)
                            .multilineTextAlignment(.leading)

                        HStack(spacing: 6) {
                            if let resolutionLabel = item.resolutionLabel {
                                badge(resolutionLabel, color: MediaPalette.accent)
                            }
                            if let seasonEpisode = item.seasonEpisodeLabel {
                                badge(seasonEpisode, color: .white.opacity(0.7))
                            }
                            if let sizeLabel = item.sizeLabel {
                                badge(sizeLabel, color: .white.opacity(0.7))
                            }
                            if let seeds = item.seedCountLabel {
                                badge("\(seeds) seed", color: .white.opacity(0.7))
                            }
                            if let relativeDate = item.relativeDateLabel {
                                Text(relativeDate)
                                    .font(.system(size: 11))
                                    .foregroundColor(MediaPalette.muted)
                            }
                        }
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(MediaPalette.muted)
                }
            }
            .padding(14)
            .background(MediaPalette.card, in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(MediaPalette.border, lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func badge(_ text: String, color: Color) -> some View {
        Text(text)
            .font(.system(size: 10, weight: .bold))
            .foregroundColor(color == MediaPalette.accent ? .black : .white)
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(color == MediaPalette.accent ? MediaPalette.accent : Color.white.opacity(0.1), in: Capsule())
    }

    private func toastView(_ message: String) -> some View {
        Text(message)
            .font(.system(size: 13, weight: .medium))
            .foregroundColor(.white)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(Color.black.opacity(0.85), in: Capsule())
            .overlay(Capsule().stroke(MediaPalette.border, lineWidth: 1))
    }

    private func handlePrimaryAction(_ item: MediaItem) {
        if item.isMagnetOrTorrent {
            sendToOffcloud(item)
        } else if vm.playOnlineURL(item.link) {
            showPlayer = true
            selectedDetailItem = nil
        } else {
            openInBrowser(item.link)
        }
    }

    private func sendToOffcloud(_ item: MediaItem) {
        let apiKey = OffcloudKeyStore.load()
        guard !apiKey.isEmpty else {
            showToast("Add your Offcloud API key in the Offcloud tab first.")
            return
        }
        sendingItemID = item.id
        Task {
            defer { sendingItemID = nil }
            do {
                _ = try await OffcloudClient(apiKey: apiKey).create(url: item.link)
                sentItemIDs.insert(item.id)
                showToast("Sent to Offcloud")
            } catch {
                showToast(error.localizedDescription)
            }
        }
    }

    private func openInBrowser(_ link: String) {
        guard let url = URL(string: link) else { return }
        UIApplication.shared.open(url)
    }

    private func showToast(_ message: String) {
        withAnimation { toast = message }
        Task {
            try? await Task.sleep(nanoseconds: 2_000_000_000)
            withAnimation { toast = nil }
        }
    }

    private func runSearch() {
        Task { await performSearch() }
    }

    @MainActor
    private func performSearch() async {
        let feedURL = currentFeedURL
        guard !feedURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            hasSearched = true
            errorMessage = MediaRSSError.missingFeedURL.localizedDescription
            items = []
            return
        }

        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        do {
            let results = try await MediaRSSService.fetch(feedTemplate: feedURL, query: searchText)
            items = results
            hasSearched = true
        } catch {
            items = []
            hasSearched = true
            errorMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        }
    }
}
