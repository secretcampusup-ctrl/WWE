import Foundation
import SwiftUI
import Combine

struct ManagedVideoDownload: Identifiable, Codable, Equatable {
    enum State: String, Codable {
        case queued
        case downloading
        case completed
        case failed
        case cancelled
    }

    let id: UUID
    let stableKey: String
    let sourceURL: String
    let title: String
    let createdAt: Date
    var state: State
    var bytesWritten: Int64
    var totalBytesExpected: Int64
    var destinationFileName: String?
    var errorMessage: String?

    var progress: Double {
        if state == .completed { return 1 }
        guard totalBytesExpected > 0 else { return 0 }
        return min(1, max(0, Double(bytesWritten) / Double(totalBytesExpected)))
    }

    var isActive: Bool {
        state == .queued || state == .downloading
    }
}

final class VideoDownloadManager: NSObject, ObservableObject, URLSessionDownloadDelegate {
    static let shared = VideoDownloadManager()
    static let sessionIdentifier = "com.mortaza.minoz.VideoPlayer.user-downloads.v1"

    @Published private(set) var downloads: [ManagedVideoDownload] = []

    private let persistenceKey = "managed_video_downloads_v1"
    private var backgroundEventsCompletionHandler: (() -> Void)?
    private var lastProgressSave = Date.distantPast

    private struct TaskDescriptor: Codable {
        let id: UUID
        let stableKey: String
        let sourceURL: String
        let title: String
        let suggestedFileName: String
    }

    private lazy var session: URLSession = {
        let configuration = URLSessionConfiguration.background(
            withIdentifier: Self.sessionIdentifier
        )
        configuration.sessionSendsLaunchEvents = true
        configuration.isDiscretionary = false
        configuration.waitsForConnectivity = true
        configuration.allowsCellularAccess = true
        configuration.allowsExpensiveNetworkAccess = true
        configuration.allowsConstrainedNetworkAccess = true
        configuration.timeoutIntervalForResource = 7 * 24 * 60 * 60
        configuration.httpMaximumConnectionsPerHost = 3

        let queue = OperationQueue()
        queue.name = "com.mortaza.minoz.VideoPlayer.user-downloads.delegate"
        queue.maxConcurrentOperationCount = 1
        return URLSession(
            configuration: configuration,
            delegate: self,
            delegateQueue: queue
        )
    }()

    private override init() {
        super.init()
        downloads = loadDownloads()
        try? FileManager.default.createDirectory(
            at: downloadDirectory,
            withIntermediateDirectories: true,
            attributes: nil
        )
        reconcileCompletedFiles()
    }

    var activeCount: Int {
        downloads.filter(\.isActive).count
    }

    var activeDownloads: [ManagedVideoDownload] {
        downloads.filter(\.isActive).sorted { $0.createdAt > $1.createdAt }
    }

    var finishedDownloads: [ManagedVideoDownload] {
        downloads.filter { !$0.isActive }.sorted { $0.createdAt > $1.createdAt }
    }

    func download(forStableKey stableKey: String) -> ManagedVideoDownload? {
        downloads.first { $0.stableKey == stableKey }
    }

    func download(forSourceURL url: URL?) -> ManagedVideoDownload? {
        guard let absolute = url?.absoluteString else { return nil }
        return downloads.first { $0.sourceURL == absolute }
    }

    func download(for link: SavedVideoLink) -> ManagedVideoDownload? {
        let keys = Set([
            link.id.uuidString,
            "saved|\(link.id.uuidString)",
            link.favoriteIdentity ?? ""
        ].filter { !$0.isEmpty })
        if let byKey = downloads.first(where: { keys.contains($0.stableKey) }) {
            return byKey
        }
        let urls = Set([
            link.url?.absoluteString ?? "",
            link.originalURL?.absoluteString ?? "",
            link.resolvedStreamURL ?? "",
            link.urlString
        ].filter { !$0.isEmpty })
        return downloads.first { urls.contains($0.sourceURL) }
    }
    func activate() {
        _ = session
        session.getAllTasks { [weak self] tasks in
            guard let self else { return }
            let restored = tasks.compactMap { task -> (TaskDescriptor, URLSessionTask)? in
                guard let descriptor = self.descriptor(from: task.taskDescription) else { return nil }
                return (descriptor, task)
            }

            DispatchQueue.main.async {
                let activeIDs = Set(restored.map { $0.0.id })
                for (descriptor, task) in restored {
                    if let index = self.downloads.firstIndex(where: { $0.id == descriptor.id }) {
                        self.downloads[index].state = .downloading
                        self.downloads[index].bytesWritten = task.countOfBytesReceived
                        self.downloads[index].totalBytesExpected = task.countOfBytesExpectedToReceive
                    } else {
                        self.downloads.append(
                            ManagedVideoDownload(
                                id: descriptor.id,
                                stableKey: descriptor.stableKey,
                                sourceURL: descriptor.sourceURL,
                                title: descriptor.title,
                                createdAt: Date(),
                                state: .downloading,
                                bytesWritten: task.countOfBytesReceived,
                                totalBytesExpected: task.countOfBytesExpectedToReceive,
                                destinationFileName: nil,
                                errorMessage: nil
                            )
                        )
                    }
                }

                for index in self.downloads.indices where self.downloads[index].isActive {
                    if !activeIDs.contains(self.downloads[index].id) {
                        self.downloads[index].state = .failed
                        self.downloads[index].errorMessage = "Download interrupted"
                    }
                }
                self.sortAndPersist()
            }
        }
    }

    func setBackgroundEventsCompletionHandler(_ handler: @escaping () -> Void) {
        backgroundEventsCompletionHandler = handler
    }

    func startDownload(
        url: URL,
        stableKey: String,
        title: String,
        suggestedFileName: String,
        headers: [String: String]
    ) {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { [weak self] in
                self?.startDownload(
                    url: url,
                    stableKey: stableKey,
                    title: title,
                    suggestedFileName: suggestedFileName,
                    headers: headers
                )
            }
            return
        }

        if let existing = download(forStableKey: stableKey) {
            if existing.isActive { return }
            if existing.state == .completed,
               let fileURL = fileURL(for: existing),
               FileManager.default.fileExists(atPath: fileURL.path) {
                return
            }
            downloads.removeAll { $0.id == existing.id }
        }

        let id = UUID()
        let descriptor = TaskDescriptor(
            id: id,
            stableKey: stableKey,
            sourceURL: url.absoluteString,
            title: title,
            suggestedFileName: suggestedFileName
        )
        downloads.insert(
            ManagedVideoDownload(
                id: id,
                stableKey: stableKey,
                sourceURL: url.absoluteString,
                title: title,
                createdAt: Date(),
                state: .queued,
                bytesWritten: 0,
                totalBytesExpected: 0,
                destinationFileName: nil,
                errorMessage: nil
            ),
            at: 0
        )
        persist()

        var request = URLRequest(url: url)
        request.timeoutInterval = 7 * 24 * 60 * 60
        for (field, value) in headers {
            request.setValue(value, forHTTPHeaderField: field)
        }

        let task = session.downloadTask(with: request)
        task.taskDescription = encoded(descriptor)
        task.priority = URLSessionTask.defaultPriority
        task.resume()

        if let index = downloads.firstIndex(where: { $0.id == id }) {
            downloads[index].state = .downloading
            persist()
        }
    }

    func cancel(_ download: ManagedVideoDownload) {
        session.getAllTasks { [weak self] tasks in
            guard let self else { return }
            for task in tasks where self.descriptor(from: task.taskDescription)?.id == download.id {
                task.cancel()
            }
            DispatchQueue.main.async {
                guard let index = self.downloads.firstIndex(where: { $0.id == download.id }) else { return }
                self.downloads[index].state = .cancelled
                self.downloads[index].errorMessage = "Cancelled"
                self.persist()
            }
        }
    }

    func removeFromList(_ download: ManagedVideoDownload) {
        if download.isActive { cancel(download) }
        downloads.removeAll { $0.id == download.id }
        persist()
    }

    func clearFinished() {
        downloads.removeAll { !$0.isActive }
        persist()
    }

    func fileURL(for download: ManagedVideoDownload) -> URL? {
        guard let name = download.destinationFileName else { return nil }
        return downloadDirectory.appendingPathComponent(name)
    }

    func urlSession(
        _ session: URLSession,
        downloadTask: URLSessionDownloadTask,
        didWriteData bytesWritten: Int64,
        totalBytesWritten: Int64,
        totalBytesExpectedToWrite: Int64
    ) {
        guard let descriptor = descriptor(from: downloadTask.taskDescription) else { return }
        DispatchQueue.main.async {
            guard let index = self.downloads.firstIndex(where: { $0.id == descriptor.id }) else { return }
            self.downloads[index].state = .downloading
            self.downloads[index].bytesWritten = totalBytesWritten
            self.downloads[index].totalBytesExpected = totalBytesExpectedToWrite
            if Date().timeIntervalSince(self.lastProgressSave) >= 1 {
                self.lastProgressSave = Date()
                self.persist()
            }
        }
    }

    func urlSession(
        _ session: URLSession,
        downloadTask: URLSessionDownloadTask,
        didFinishDownloadingTo location: URL
    ) {
        guard let descriptor = descriptor(from: downloadTask.taskDescription) else { return }
        if let response = downloadTask.response as? HTTPURLResponse,
           !(200...299).contains(response.statusCode) {
            try? FileManager.default.removeItem(at: location)
            markFailed(id: descriptor.id, message: "Server error \(response.statusCode)")
            return
        }

        do {
            try FileManager.default.createDirectory(
                at: downloadDirectory,
                withIntermediateDirectories: true,
                attributes: nil
            )
            let responseName = downloadTask.response?.suggestedFilename
            let preferredName = preferredDownloadFileName(
                responseFileName: responseName,
                suggestedFileName: descriptor.suggestedFileName,
                sourceURL: URL(string: descriptor.sourceURL)
            )
            let destination = uniqueDestination(
                fileName: safeFileName(
                    preferredName,
                    fallbackFileName: descriptor.suggestedFileName,
                    fallbackURL: URL(string: descriptor.sourceURL)
                )
            )
            if FileManager.default.fileExists(atPath: destination.path) {
                try FileManager.default.removeItem(at: destination)
            }
            try FileManager.default.moveItem(at: location, to: destination)

            DispatchQueue.main.async {
                guard let index = self.downloads.firstIndex(where: { $0.id == descriptor.id }) else { return }
                self.downloads[index].state = .completed
                self.downloads[index].bytesWritten = max(
                    self.downloads[index].bytesWritten,
                    downloadTask.countOfBytesReceived
                )
                if self.downloads[index].totalBytesExpected <= 0 {
                    self.downloads[index].totalBytesExpected = self.downloads[index].bytesWritten
                }
                self.downloads[index].destinationFileName = destination.lastPathComponent
                self.downloads[index].errorMessage = nil
                self.sortAndPersist()
            }
        } catch {
            try? FileManager.default.removeItem(at: location)
            markFailed(id: descriptor.id, message: error.localizedDescription)
        }
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        didCompleteWithError error: Error?
    ) {
        guard let error,
              let descriptor = descriptor(from: task.taskDescription) else { return }
        let nsError = error as NSError
        if nsError.domain == NSURLErrorDomain,
           nsError.code == NSURLErrorCancelled {
            return
        }
        markFailed(id: descriptor.id, message: error.localizedDescription)
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async {
            let handler = self.backgroundEventsCompletionHandler
            self.backgroundEventsCompletionHandler = nil
            handler?()
        }
    }

    private var downloadDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Downloads", isDirectory: true)
    }

    private func markFailed(id: UUID, message: String) {
        DispatchQueue.main.async {
            guard let index = self.downloads.firstIndex(where: { $0.id == id }),
                  self.downloads[index].state != .completed else { return }
            self.downloads[index].state = .failed
            self.downloads[index].errorMessage = message
            self.persist()
        }
    }

    private func preferredDownloadFileName(
        responseFileName: String?,
        suggestedFileName: String,
        sourceURL: URL?
    ) -> String {
        let suggested = suggestedFileName.trimmingCharacters(in: .whitespacesAndNewlines)
        let response = responseFileName?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

        if !suggested.isEmpty, isVideoFileName(suggested) {
            return suggested
        }

        if !response.isEmpty, isVideoFileName(response) {
            return response
        }

        if !suggested.isEmpty {
            return suggested
        }

        if let sourceURL, isVideoFileName(sourceURL.lastPathComponent) {
            return sourceURL.lastPathComponent
        }

        return "video.mp4"
    }

    private func isVideoFileName(_ value: String) -> Bool {
        let ext = (value as NSString).pathExtension.lowercased()
        guard !ext.isEmpty else { return false }
        return isVideoExtension(ext)
    }

    private func isVideoExtension(_ ext: String) -> Bool {
        ["mp4", "m4v", "mov", "mkv", "avi", "webm", "wmv", "flv", "ts", "m3u8"].contains(ext.lowercased())
    }
    private func safeFileName(
        _ proposed: String,
        fallbackFileName: String,
        fallbackURL: URL?
    ) -> String {
        let invalid = CharacterSet(charactersIn: "/?%*|<>:\\")
        var name = proposed
            .components(separatedBy: invalid)
            .joined(separator: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = "video" }

        let currentExtension = (name as NSString).pathExtension.lowercased()
        if currentExtension.isEmpty || !isVideoExtension(currentExtension) {
            let baseName = currentExtension.isEmpty ? name : (name as NSString).deletingPathExtension
            let suggestedExtension = (fallbackFileName as NSString).pathExtension.lowercased()
            let remoteExtension = fallbackURL?.pathExtension.lowercased() ?? ""
            let ext: String
            if isVideoExtension(suggestedExtension) {
                ext = suggestedExtension
            } else if isVideoExtension(remoteExtension) {
                ext = remoteExtension
            } else {
                ext = "mp4"
            }
            name = baseName + ".\(ext)"
        }
        return name
    }

    private func uniqueDestination(fileName: String) -> URL {
        let original = downloadDirectory.appendingPathComponent(fileName)
        guard FileManager.default.fileExists(atPath: original.path) else { return original }

        let base = (fileName as NSString).deletingPathExtension
        let ext = (fileName as NSString).pathExtension
        var number = 2
        while true {
            let candidateName = ext.isEmpty
                ? "\(base) \(number)"
                : "\(base) \(number).\(ext)"
            let candidate = downloadDirectory.appendingPathComponent(candidateName)
            if !FileManager.default.fileExists(atPath: candidate.path) { return candidate }
            number += 1
        }
    }

    private func encoded(_ descriptor: TaskDescriptor) -> String? {
        guard let data = try? JSONEncoder().encode(descriptor) else { return nil }
        return data.base64EncodedString()
    }

    private func descriptor(from value: String?) -> TaskDescriptor? {
        guard let value,
              let data = Data(base64Encoded: value) else { return nil }
        return try? JSONDecoder().decode(TaskDescriptor.self, from: data)
    }

    private func persist() {
        guard let data = try? JSONEncoder().encode(downloads) else { return }
        UserDefaults.standard.set(data, forKey: persistenceKey)
    }

    private func sortAndPersist() {
        downloads.sort { lhs, rhs in
            if lhs.isActive != rhs.isActive { return lhs.isActive }
            return lhs.createdAt > rhs.createdAt
        }
        persist()
    }

    private func loadDownloads() -> [ManagedVideoDownload] {
        guard let data = UserDefaults.standard.data(forKey: persistenceKey),
              let decoded = try? JSONDecoder().decode([ManagedVideoDownload].self, from: data) else {
            return []
        }
        return decoded
    }

    private func reconcileCompletedFiles() {
        var changed = false
        for index in downloads.indices where downloads[index].state == .completed {
            guard let fileURL = fileURL(for: downloads[index]),
                  FileManager.default.fileExists(atPath: fileURL.path) else {
                downloads[index].state = .failed
                downloads[index].errorMessage = "File removed from Files"
                downloads[index].destinationFileName = nil
                changed = true
                continue
            }
        }
        if changed { persist() }
    }
}

struct DownloadManagerView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var manager = VideoDownloadManager.shared

    var body: some View {
        NavigationStack {
            Group {
                if manager.downloads.isEmpty {
                    VStack(spacing: 14) {
                        Image(systemName: "arrow.down.circle")
                            .font(.system(size: 52, weight: .light))
                            .foregroundColor(.blue.opacity(0.75))
                        Text("No downloads yet")
                            .font(.headline)
                            .foregroundColor(.white)
                        Text("Downloaded videos will appear in Files / Murtadha / Downloads.")
                            .font(.footnote)
                            .foregroundColor(.white.opacity(0.5))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 34)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        if !manager.activeDownloads.isEmpty {
                            Section("Downloading") {
                                ForEach(manager.activeDownloads) { download in
                                    DownloadManagerRow(download: download)
                                }
                            }
                        }

                        if !manager.finishedDownloads.isEmpty {
                            Section("Finished") {
                                ForEach(manager.finishedDownloads) { download in
                                    DownloadManagerRow(download: download)
                                }
                            }
                        }
                    }
                    .scrollContentBackground(.hidden)
                    .listStyle(.insetGrouped)
                }
            }
            .background(AppTheme.bg.ignoresSafeArea())
            .navigationTitle("Downloads")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
                if !manager.finishedDownloads.isEmpty {
                    ToolbarItem(placement: .primaryAction) {
                        Button("Clear") { manager.clearFinished() }
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

private struct DownloadManagerRow: View {
    @ObservedObject private var manager = VideoDownloadManager.shared
    let download: ManagedVideoDownload

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(iconColor.opacity(0.16))
                    .frame(width: 46, height: 46)
                Image(systemName: iconName)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(iconColor)
            }

            VStack(alignment: .leading, spacing: 6) {
                Text(VideoTitleFormatter.title(from: download.title))
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(2)

                if download.isActive {
                    ProgressView(value: download.progress)
                        .tint(.blue)
                    Text(progressLabel)
                        .font(.system(size: 11, weight: .medium).monospacedDigit())
                        .foregroundColor(.white.opacity(0.55))
                } else {
                    Text(statusLabel)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(download.state == .failed ? .red.opacity(0.85) : .white.opacity(0.5))
                        .lineLimit(2)
                }
            }

            Spacer(minLength: 4)

            if download.isActive {
                Button(role: .destructive) { manager.cancel(download) } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 20))
                }
                .buttonStyle(.plain)
            } else if download.state == .completed,
                      let fileURL = manager.fileURL(for: download) {
                ShareLink(item: fileURL) {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.blue)
                }
            } else {
                Button { manager.removeFromList(download) } label: {
                    Image(systemName: "minus.circle.fill")
                        .font(.system(size: 20))
                        .foregroundColor(.white.opacity(0.45))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 5)
        .listRowBackground(AppTheme.card)
    }

    private var iconName: String {
        switch download.state {
        case .queued, .downloading: return "arrow.down.circle.fill"
        case .completed: return "checkmark.circle.fill"
        case .failed: return "exclamationmark.triangle.fill"
        case .cancelled: return "xmark.circle.fill"
        }
    }

    private var iconColor: Color {
        switch download.state {
        case .queued, .downloading: return .blue
        case .completed: return .green
        case .failed: return .red
        case .cancelled: return .orange
        }
    }

    private var progressLabel: String {
        let percent = Int((download.progress * 100).rounded())
        if download.totalBytesExpected > 0 {
            return "\(percent)%  ·  \(byteLabel(download.bytesWritten)) / \(byteLabel(download.totalBytesExpected))"
        }
        return "Downloading  ·  \(byteLabel(download.bytesWritten))"
    }

    private var statusLabel: String {
        switch download.state {
        case .queued: return "Waiting"
        case .downloading: return progressLabel
        case .completed: return "Saved in Files / Murtadha / Downloads"
        case .failed: return download.errorMessage ?? "Download failed"
        case .cancelled: return "Cancelled"
        }
    }

    private func byteLabel(_ bytes: Int64) -> String {
        guard bytes > 0 else { return "0 MB" }
        let formatter = ByteCountFormatter()
        formatter.allowedUnits = [.useMB, .useGB]
        formatter.countStyle = .file
        return formatter.string(fromByteCount: bytes)
    }
}
struct VideoDownloadStateOverlay: View {
    let download: ManagedVideoDownload
    var compact: Bool = false

    var body: some View {
        ZStack {
            if download.isActive {
                Color.black.opacity(0.32)
                VStack(spacing: compact ? 5 : 8) {
                    ProgressView(value: download.progress)
                        .tint(.blue)
                        .frame(width: compact ? 48 : 76)
                    Text(progressText)
                        .font(.system(size: compact ? 9 : 11, weight: .bold).monospacedDigit())
                        .foregroundColor(.white)
                }
                .padding(.horizontal, compact ? 8 : 12)
                .padding(.vertical, compact ? 7 : 10)
                .background(Color.black.opacity(0.72), in: Capsule())
            } else if download.state == .completed {
                VStack {
                    HStack {
                        Spacer()
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: compact ? 18 : 22, weight: .bold))
                            .foregroundColor(.green)
                            .padding(compact ? 6 : 8)
                    }
                    Spacer()
                }
            }
        }
        .allowsHitTesting(false)
    }

    private var progressText: String {
        switch download.state {
        case .queued:
            return "Queued"
        case .downloading:
            return "\(Int((download.progress * 100).rounded()))%"
        case .completed:
            return "Done"
        case .failed:
            return "Failed"
        case .cancelled:
            return "Cancelled"
        }
    }
}