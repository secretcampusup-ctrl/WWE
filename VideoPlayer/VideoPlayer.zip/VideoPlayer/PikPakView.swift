import SwiftUI
import PhotosUI
import UIKit

/// Recent Videos / Watch History — clean medium poster grid.
struct RecentVideosView: View {
    @ObservedObject var vm: AppViewModel
    var isActive: Bool = true
    @State private var showPlayer = false
    @State private var detailShowPlayer = false
    @State private var detailLink: SavedVideoLink?
    @State private var renameTarget: SavedVideoLink?
    @State private var renameText = ""
    @State private var thumbTarget: SavedVideoLink?
    @State private var searchCoverTarget: SavedVideoLink?
    @State private var photoItem: PhotosPickerItem?
    @State private var notice: String?

    private let gridColumns = [
        GridItem(.flexible(), spacing: 10, alignment: .top),
        GridItem(.flexible(), spacing: 10, alignment: .top)
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    headerBar

                    if vm.recentLinks.isEmpty {
                        emptyState
                    } else {
                        LazyVGrid(columns: gridColumns, alignment: .center, spacing: 10) {
                            ForEach(vm.recentLinks) { link in
                                RecentVideoCard(
                                    link: link,
                                    onPlay: { detailLink = link },
                                    onRename: {
                                        renameText = link.title
                                        renameTarget = link
                                    },
                                    onChangeThumb: { thumbTarget = link },
                                    onSearchThumb: { searchCoverTarget = link },
                                    onDelete: {
                                        withAnimation(.easeInOut(duration: 0.2)) {
                                            vm.deleteSavedLink(link)
                                        }
                                    }
                                )
                                // Force equal cell footprint so resume UI never stretches neighbors.
                                .frame(maxWidth: .infinity, alignment: .top)
                            }
                        }
                        .padding(.horizontal, 10)
                    }
                }
                .padding(.top, 8)
                .padding(.bottom, 28)
            }
            .background(AppTheme.bg.ignoresSafeArea())
            .navigationTitle("Recent")
            .navigationBarTitleDisplayMode(.large)
            .fullScreenCover(isPresented: $showPlayer, onDismiss: {
                UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
            }) {
                if let url = vm.nowPlayingURL, let file = vm.nowPlaying {
                    VideoPlayerView(
                        url: url,
                        title: file.name,
                        resumeAt: vm.nowPlayingResumeAt,
                        linkId: vm.nowPlayingLinkId,
                        httpHeaders: vm.nowPlayingHeaders
                    ) { seconds, duration, w, h in
                        vm.updatePlaybackProgress(
                            seconds: seconds,
                            duration: duration,
                            width: w,
                            height: h,
                            linkId: vm.nowPlayingLinkId,
                            streamURL: url
                        )
                    }
                } else {
                    ImmediatePlayerLoadingView()
                }
            }
            .fullScreenCover(item: $detailLink) { link in
                if let url = link.url {
                    VideoDetailsView(
                        vm: vm,
                        item: VideoDetailsItem(
                            id: link.id.uuidString,
                            title: link.title,
                            url: url,
                            posterCacheKey: link.favoriteIdentity ?? "saved|\(link.id.uuidString)",
                            customPosterFileName: link.thumbnailFileName,
                            fileSizeBytes: link.fileSizeBytes,
                            durationSeconds: link.durationSeconds,
                            videoWidth: link.videoWidth,
                            videoHeight: link.videoHeight,
                            fileExtension: link.fileExtension,
                            source: link.hostLabel,
                            resumePositionSeconds: link.resumePositionSeconds
                        ),
                        onPlay: { play(link, fromDetails: true) },
                        onDelete: {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                vm.deleteSavedLink(link)
                            }
                        },
                        dismissOnPlay: false
                    )
                    .fullScreenCover(isPresented: $detailShowPlayer) {
                        ResolvedPlayerScreen(vm: vm)
                    }
                } else {
                    Text("This item does not contain a playable video URL.")
                        .padding()
                }
            }
            .alert("Rename video", isPresented: Binding(
                get: { renameTarget != nil },
                set: { if !$0 { renameTarget = nil } }
            )) {
                TextField("Title", text: $renameText)
                Button("Cancel", role: .cancel) { renameTarget = nil }
                Button("Save") {
                    if let target = renameTarget {
                        vm.renameSavedLink(target, to: renameText)
                        toast("Renamed")
                    }
                    renameTarget = nil
                }
            } message: {
                Text("Choose a display name for this video.")
            }
            .photosPicker(isPresented: Binding(
                get: { thumbTarget != nil },
                set: { if !$0 { thumbTarget = nil } }
            ), selection: $photoItem, matching: .images)
            .onChange(of: photoItem) { newItem in
                guard let newItem, let target = thumbTarget else { return }
                Task {
                    if let data = try? await newItem.loadTransferable(type: Data.self),
                       let image = UIImage(data: data) {
                        await MainActor.run {
                            vm.setCustomThumbnail(image, for: target)
                            toast("Cover updated")
                        }
                    }
                    await MainActor.run {
                        photoItem = nil
                        thumbTarget = nil
                    }
                }
            }
            .sheet(item: $searchCoverTarget) { target in
                YandexImageSearchView(initialQuery: target.displayTitle) { image in
                    vm.setCustomThumbnail(image, for: target)
                    toast("Cover updated")
                    searchCoverTarget = nil
                }
            }
            .overlay(alignment: .bottom) {
                if let notice {
                    Text(notice)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(Color.green.opacity(0.92), in: Capsule())
                        .padding(.bottom, 24)
                        .transition(.opacity)
                }
            }
        }
        .preferredColorScheme(.dark)
        .task(id: recentPosterPrefetchID) {
            guard isActive else { return }
            VideoThumbnailLoader.schedulePrefetchSavedLinks(vm.recentLinks)
        }
    }

    private var recentPosterPrefetchID: [String] {
        ["active|\(isActive)"] + vm.recentLinks.map {
            "\($0.id.uuidString)|\($0.url?.absoluteString ?? "")|\($0.thumbnailFileName ?? "")|\($0.remotePosterURL ?? "")"
        }
    }

    // MARK: - Header

    private var headerBar: some View {
        HStack(alignment: .center, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Watch History")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white)
                Text("Tap to play · buttons to edit")
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.4))
            }
            Spacer(minLength: 8)
            Text("\(vm.recentLinks.count)")
                .font(.system(size: 13, weight: .bold).monospacedDigit())
                .foregroundColor(.green)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Color.green.opacity(0.15), in: Capsule())
                .overlay(
                    Capsule().stroke(Color.green.opacity(0.3), lineWidth: 1)
                )
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 4)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color.white.opacity(0.05))
                    .frame(width: 88, height: 88)
                Image(systemName: "clock.arrow.circlepath")
                    .font(.system(size: 36, weight: .medium))
                    .foregroundColor(.white.opacity(0.28))
            }
            Text("No recent videos")
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(.white.opacity(0.6))
            Text("Play something from Library — it will appear here as a poster card.")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.35))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 72)
    }

    @MainActor
    private func play(_ link: SavedVideoLink, fromDetails: Bool = false) {
        vm.nowPlaying = nil
        vm.nowPlayingURL = nil
        vm.nowPlayingHeaders = nil
        if fromDetails {
            detailShowPlayer = true
        } else {
            showPlayer = true
        }

        Task { @MainActor in
            await vm.playSavedLinkAsync(link)
            if vm.nowPlayingURL == nil {
                if fromDetails {
                    detailShowPlayer = false
                } else {
                    showPlayer = false
                }
            }
        }
    }
    private func toast(_ text: String) {
        withAnimation { notice = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
            withAnimation { if notice == text { notice = nil } }
        }
    }
}

// MARK: - Medium poster card (2-column grid cell)

struct RecentVideoCard: View {
    let link: SavedVideoLink
    let onPlay: () -> Void
    let onRename: () -> Void
    let onChangeThumb: () -> Void
    let onSearchThumb: () -> Void
    let onDelete: () -> Void
    @ObservedObject private var downloadManager = VideoDownloadManager.shared

    /// Classic medium poster aspect (width : height ≈ 2 : 3).
    private let posterAspect: CGFloat = 16.0 / 9.0

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // MARK: Poster — fixed 2:3 ratio so grid cells never overflow or stack
            Button(action: onPlay) {
                Color.black
                    .aspectRatio(posterAspect, contentMode: .fit)
                    .overlay {
                        PosterThumbnailView(
                            url: link.url,
                            remotePosterURL: link.remotePosterURL.flatMap { URL(string: $0) },
                            customFileName: link.thumbnailFileName,
                            stableCacheKey: link.favoriteIdentity ?? "saved|\(link.id.uuidString)",
                            title: link.title,
                            badge: link.fileExtension
                        )
                    }
                    .overlay {
                        // Soft bottom fade for badge legibility
                        VStack {
                            Spacer()
                            LinearGradient(
                                colors: [.clear, .black.opacity(0.75)],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                            .frame(height: 40)
                        }
                    }
                    .overlay {
                        Image(systemName: "play.circle.fill")
                            .font(.system(size: 24))
                            .symbolRenderingMode(.palette)
                            .foregroundStyle(.white, Color.green.opacity(0.92))
                            .shadow(color: .black.opacity(0.45), radius: 6, y: 2)
                    }
                    .overlay(alignment: .top) {
                        // Always reserve chip row height so Resume presence cannot change layout.
                        HStack(alignment: .top, spacing: 6) {
                            chip("Resume", color: .orange)
                                .opacity(link.hasResumePoint ? 1 : 0)
                                .accessibilityHidden(!link.hasResumePoint)
                            Spacer(minLength: 4)
                            ResolutionBadgeView(tier: link.resolutionTier, compact: true)
                        }
                        .padding(8)
                        .frame(height: 30, alignment: .top)
                    }
                    .overlay(alignment: .bottom) {
                        HStack(alignment: .bottom, spacing: 6) {
                            chip(link.fileExtension, color: sourceColor)
                            Spacer(minLength: 4)
                            if let duration = formatDuration(link.durationSeconds) {
                                chip(duration, color: Color.black.opacity(0.65))
                            } else {
                                // Placeholder keeps bottom chip row height stable.
                                chip(" ", color: .clear)
                                    .opacity(0)
                                    .accessibilityHidden(true)
                            }
                        }
                        .padding(8)
                        .frame(height: 30, alignment: .bottom)
                    }
                    .overlay(alignment: .bottom) {
                        // Always draw the track (3pt). Fill only when resume progress exists.
                        // Conditional overlay height was making some cards feel uneven.
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                Rectangle()
                                    .fill(Color.white.opacity(link.hasResumePoint ? 0.15 : 0))
                                if link.hasResumePoint, let progress = resumeProgress {
                                    Rectangle()
                                        .fill(Color.orange)
                                        .frame(width: max(4, geo.size.width * CGFloat(progress)))
                                }
                            }
                        }
                        .frame(height: 3)
                    }
                    .overlay {
                        if let currentDownload {
                            VideoDownloadStateOverlay(download: currentDownload, compact: true)
                        }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(Color.white.opacity(0.08), lineWidth: 1)
                    )
                    .shadow(color: .black.opacity(0.35), radius: 8, y: 4)
            }
            .buttonStyle(.plain)
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())

            // MARK: Title + meta — fixed heights so every card matches its neighbor
            VStack(alignment: .leading, spacing: 4) {
                Text(displayTitle)
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, minHeight: 26, maxHeight: 26, alignment: .topLeading)

                HStack(spacing: 6) {
                    Text(relativeDate(link.lastPlayed ?? link.dateAdded))
                        .font(.system(size: 8, weight: .medium))
                        .foregroundColor(.white.opacity(0.42))
                        .lineLimit(1)
                    // Always reserve resume-time width so meta row height never changes.
                    Group {
                        if link.hasResumePoint, let pos = link.resumePositionSeconds {
                            Text("·")
                                .foregroundColor(.white.opacity(0.25))
                            Text(formatClock(pos))
                                .font(.system(size: 8, weight: .semibold).monospacedDigit())
                                .foregroundColor(.orange.opacity(0.95))
                        } else {
                            Text("· 00:00")
                                .font(.system(size: 8, weight: .semibold).monospacedDigit())
                                .opacity(0)
                        }
                    }
                    .lineLimit(1)
                    Spacer(minLength: 0)
                }
                .frame(maxWidth: .infinity, minHeight: 12, maxHeight: 12, alignment: .leading)
            }
            .frame(maxWidth: .infinity, minHeight: 42, maxHeight: 42, alignment: .topLeading)
            .padding(.top, 10)
            .padding(.horizontal, 2)

        }
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .contentShape(Rectangle())
        .clipped()
        .contextMenu {
            Button(action: onPlay) {
                Label(link.hasResumePoint ? "Resume" : "Play", systemImage: "play.fill")
            }
            Button(action: onRename) {
                Label("Rename", systemImage: "pencil")
            }
            Button(action: onChangeThumb) {
                Label("Change Cover", systemImage: "photo")
            }
            Button(action: onSearchThumb) {
                Label("Search Cover", systemImage: "magnifyingglass")
            }
            Divider()
            Button(role: .destructive, action: onDelete) {
                Label("Delete", systemImage: "trash")
            }
        }
    }


    private func chip(_ text: String, color: Color) -> some View {
        Text(text)
            .font(.system(size: 9, weight: .bold))
            .foregroundColor(.white)
            .padding(.horizontal, 7)
            .padding(.vertical, 3)
            .background(color, in: Capsule())
            .lineLimit(1)
    }

    // MARK: - Helpers

    /// Prefer a clean title; fall back to a shortened filename.
    private var displayTitle: String {
        link.displayTitle
    }

    private var resumeProgress: Double? {
        guard let pos = link.resumePositionSeconds, let dur = link.durationSeconds, dur > 0 else {
            return link.hasResumePoint ? 0.35 : nil
        }
        return min(1, max(0, pos / dur))
    }

    private var currentDownload: ManagedVideoDownload? {
        downloadManager.download(for: link)
    }

    private var sourceColor: Color {
        switch link.source {
        case .pikpak: return Color.blue.opacity(0.85)
        case .webdav: return Color.orange.opacity(0.85)
        case .offcloud: return Color.cyan.opacity(0.85)
        case .hls: return Color.purple.opacity(0.85)
        case .direct: return Color.black.opacity(0.55)
        }
    }

    private func relativeDate(_ date: Date) -> String {
        let f = RelativeDateTimeFormatter()
        f.unitsStyle = .abbreviated
        return f.localizedString(for: date, relativeTo: Date())
    }

    private func formatDuration(_ seconds: Double?) -> String? {
        guard let seconds, seconds.isFinite, seconds > 0 else { return nil }
        return formatClock(seconds)
    }

    private func formatClock(_ seconds: Double) -> String {
        let s = max(0, Int(seconds.rounded(.down)))
        let h = s / 3600
        let m = (s % 3600) / 60
        let r = s % 60
        if h > 0 {
            return String(format: "%d:%02d:%02d", h, m, r)
        }
        return String(format: "%d:%02d", m, r)
    }
}

// Keep old name available so any leftover references compile
typealias PikPakView = RecentVideosView
