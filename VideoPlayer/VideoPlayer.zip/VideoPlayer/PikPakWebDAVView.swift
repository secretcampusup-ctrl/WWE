import SwiftUI
import UIKit
import Combine

/// Dedicated PikPak WebDAV tab. Other WebDAV browsers keep their normal folder list.
struct PikPakWebDAVView: View {
    @ObservedObject var vm: AppViewModel
    var homeToken: Int = 0
    var isActive: Bool = true
    @State private var files: [WebDAVFile] = []
    @State private var locations: [PikPakLocation] = []
    @State private var showingPlayer = false
    @State private var detailShowingPlayer = false
    @State private var selectedVideoFile: WebDAVFile?
    @State private var showingSetup = false
    @State private var isRefreshing = false
    @State private var folderCoverVersion = 0
    @State private var showingAutoSync = false

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 8), count: 3)
    /// Videos smaller than this are hidden in the PikPak section.
    private static let minimumVideoSizeBytes: Int64 = 500 * 1024 * 1024 // 500 MB
    private let mainFolderNames: Set<String> = [
        "my pack", "my tiktok", "top", "korean movies", "english series",
        "my upload", "anime", "english movies", "elza", "korean drama"
    ]

    private var server: WebDAVServer? {
        vm.servers.first { $0.host.lowercased().contains("dav.mypikpak.com") }
    }

    private var location: PikPakLocation {
        locations.last ?? PikPakLocation(title: "PikPak", path: "", flattensFolders: false, extractSmallFolders: false)
    }

    var body: some View {
        NavigationView {
            Group {
                if let server {
                    browser(for: server)
                } else {
                    setupPrompt
                }
            }
            .background(
                ZStack {
                    AppTheme.bg
                    RadialGradient(
                        colors: [Color.cyan.opacity(0.10), Color.clear],
                        center: .topTrailing,
                        startRadius: 10,
                        endRadius: 420
                    )
                }
                .ignoresSafeArea()
            )
            .navigationTitle(location.title)
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button { Task { await refreshCurrentLocation() } } label: {
                        Image(systemName: "arrow.clockwise")
                            .rotationEffect(.degrees(isRefreshing ? 360 : 0))
                            .animation(isRefreshing ? .linear(duration: 0.9).repeatForever(autoreverses: false) : .default, value: isRefreshing)
                    }
                    .disabled(isRefreshing || server == nil)

                    Button { showingAutoSync = true } label: {
                        Image(systemName: PikPakAutoSyncManager.shared.isEnabled
                              ? "bolt.fill" : "bolt.slash")
                    }

                    Button { showingSetup = true } label: {
                        Image(systemName: "gearshape")
                    }
                }
            }
        }
        .sheet(isPresented: $showingAutoSync) {
            PikPakAutoSyncSettingsView(vm: vm)
        }
        // Folder changes are immediate: no slide, fade or list transition.
        .transaction { transaction in
            transaction.animation = nil
            transaction.disablesAnimations = true
        }
        .fullScreenCover(item: $selectedVideoFile) { file in
            if let server,
               let url = WebDAVClient(server: server).streamURL(for: file) {
                let saved = vm.savedLinks.first {
                    $0.url?.absoluteString == url.absoluteString
                        || $0.resolvedStreamURL == url.absoluteString
                }
                VideoDetailsView(
                    vm: vm,
                    item: VideoDetailsItem(
                        id: coverKey(for: file, server: server),
                        title: file.name,
                        url: url,
                        httpHeaders: WebDAVClient(server: server).streamHeaders(),
                        posterCacheKey: coverKey(for: file, server: server),
                        customPosterFileName: saved?.thumbnailFileName,
                        customPosterImage: PikPakFolderCoverStore.image(for: coverKey(for: file, server: server)),
                        fileSizeBytes: file.size,
                        durationSeconds: saved?.durationSeconds,
                        videoWidth: saved?.videoWidth,
                        videoHeight: saved?.videoHeight,
                        fileExtension: file.fileExtension,
                        source: "PikPak",
                        resumePositionSeconds: saved?.resumePositionSeconds
                    ),
                    onPlay: { play(file, on: server, fromDetails: true) },
                    onDelete: { delete(file, on: server) },
                    dismissOnPlay: false
                )
                .fullScreenCover(isPresented: $detailShowingPlayer, onDismiss: {
                    folderCoverVersion &+= 1
                }) {
                    ResolvedPlayerScreen(vm: vm)
                }
            } else {
                Text("Could not open this PikPak video.")
                    .padding()
            }
        }
        .sheet(isPresented: $showingSetup) {
            WebDAVSettingsView(vm: vm)
        }
        .fullScreenCover(isPresented: $showingPlayer, onDismiss: {
            folderCoverVersion &+= 1
        }) {
            if let url = vm.nowPlayingURL, let file = vm.nowPlaying {
                VideoPlayerView(
                    url: url,
                    title: file.name,
                    resumeAt: vm.nowPlayingResumeAt,
                    linkId: vm.nowPlayingLinkId,
                    httpHeaders: vm.nowPlayingHeaders
                ) { seconds, duration, width, height in
                    vm.updatePlaybackProgress(
                        seconds: seconds,
                        duration: duration,
                        width: width,
                        height: height,
                        linkId: vm.nowPlayingLinkId,
                        streamURL: url
                    )
                }
            }
        }
        .onAppear {
            loadCurrentLocation()
            scheduleVisiblePosterPrefetch()
        }
        .onChange(of: vm.servers.count) { _ in loadCurrentLocation() }
        .onChange(of: homeToken) { _ in
            locations = []
            vm.errorMessage = nil
            loadCurrentLocation()
        }
        .onChange(of: files.map(\.id)) { _ in
            scheduleVisiblePosterPrefetch()
        }
        .onChange(of: isActive) { active in
            if active { scheduleVisiblePosterPrefetch() }
        }
    }

    /// Kick off background poster generation for visible videos (survives scroll cancellation).
    private func scheduleVisiblePosterPrefetch() {
        guard isActive, let server else { return }
        let requests = posterRequests(for: files, server: server)
        guard !requests.isEmpty else { return }
        VideoThumbnailLoader.schedulePrefetchPosters(requests)
    }

    private var pikPakPosterPrefetchID: [String] {
        guard let server else { return ["active|\(isActive)"] }
        return ["active|\(isActive)"] + files.filter { !$0.isDirectory && $0.isVideo }.map {
            "\(server.id.uuidString)|\($0.path)|\($0.name)"
        }
    }

    @ViewBuilder
    private func browser(for server: WebDAVServer) -> some View {
        if isRefreshing && files.isEmpty {
            ProgressView("Loading...")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else if let error = vm.errorMessage, files.isEmpty {
            VStack(spacing: 14) {
                Image(systemName: "wifi.slash").font(.system(size: 38)).foregroundColor(.gray)
                Text(error).font(.footnote).foregroundColor(.gray).multilineTextAlignment(.center)
                Button("Retry") { Task { await refreshCurrentLocation() } }
            }
            .padding(24)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    if !locations.isEmpty {
                        Button {
                            updateFolderImmediately {
                                locations.removeLast()
                            }
                            loadCurrentLocation()
                        } label: {
                            HStack(spacing: 5) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 12, weight: .bold))
                                Text("Back")
                                    .font(.system(size: 13, weight: .semibold))
                            }
                            .foregroundColor(.cyan)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .background(Color.cyan.opacity(0.14), in: Capsule())
                            .overlay(Capsule().stroke(Color.cyan.opacity(0.25), lineWidth: 1))
                        }
                        .buttonStyle(.plain)
                    }

                    if location.flattensFolders {
                        Text("VIDEOS IN THIS FOLDER")
                            .font(.system(size: 11, weight: .bold))
                            .tracking(0.6)
                            .foregroundColor(AppTheme.mutedDeep)
                    }

                    if files.isEmpty {
                        VStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(Color.white.opacity(0.06))
                                    .frame(width: 76, height: 76)
                                Image(systemName: "film")
                                    .font(.system(size: 30, weight: .medium))
                                    .foregroundColor(AppTheme.muted)
                            }
                            Text("No videos here")
                                .font(.headline)
                                .foregroundColor(.white)
                            Text("There are no playable videos in this folder yet.")
                                .font(.footnote)
                                .foregroundColor(AppTheme.mutedDeep)
                                .multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.top, 80)
                    } else {
                        LazyVGrid(columns: columns, spacing: 18) {
                            ForEach(files) { file in
                                PikPakFilePoster(
                                    file: file,
                                    server: server,
                                    posterRefreshVersion: folderCoverVersion,
                                    folderCover: folderCover(for: file, server: server),
                                    usesMainFolderArtwork: location.path.isEmpty
                                        && file.isDirectory
                                        && mainFolderNames.contains(file.name.trimmingCharacters(in: .whitespacesAndNewlines).lowercased())
                                ) {
                                    open(file, on: server)
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 12)
            }
            .refreshable {
                await refreshCurrentLocation()
            }
        }
    }

    private var setupPrompt: some View {
        VStack(spacing: 22) {
            Spacer(minLength: 0)

            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [Color.cyan.opacity(0.35), Color.indigo.opacity(0.28)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 108, height: 108)
                    .blur(radius: 1)
                Circle()
                    .stroke(Color.cyan.opacity(0.35), lineWidth: 1)
                    .frame(width: 108, height: 108)
                Image(systemName: "externaldrive.connected.to.line.below")
                    .font(.system(size: 40, weight: .medium))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [Color.white, Color.cyan],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
            }

            VStack(spacing: 8) {
                Text("Connect PikPak")
                    .font(.title2.weight(.bold))
                    .foregroundStyle(AppTheme.titleGradient)
                Text("Add your PikPak WebDAV username and password to browse and stream your library right here.")
                    .font(.subheadline)
                    .foregroundColor(AppTheme.muted)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
            }

            Button {
                showingSetup = true
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "plus.circle.fill")
                    Text("Set Up PikPak")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
            }
            .buttonStyle(.plain)
            .foregroundColor(.black)
            .background(AppTheme.accentGradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .padding(.horizontal, 44)
            .shadow(color: AppTheme.accent.opacity(0.35), radius: 14, y: 6)

            HStack(spacing: 18) {
                setupHint(icon: "bolt.fill", text: "Fast streaming")
                setupHint(icon: "square.grid.2x2.fill", text: "Auto covers")
                setupHint(icon: "lock.fill", text: "Private")
            }
            .padding(.top, 4)

            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func setupHint(icon: String, text: String) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(.cyan)
            Text(text)
                .font(.system(size: 10, weight: .medium))
                .foregroundColor(AppTheme.mutedDeep)
        }
        .frame(width: 78)
    }

    private func open(_ file: WebDAVFile, on server: WebDAVServer) {
        if file.isDirectory {
            let opensMainFolder = locations.isEmpty
                && mainFolderNames.contains(file.name.trimmingCharacters(in: .whitespacesAndNewlines).lowercased())
            updateFolderImmediately {
                locations.append(PikPakLocation(
                    title: file.name,
                    path: file.path,
                    flattensFolders: !opensMainFolder,
                    extractSmallFolders: opensMainFolder
                ))
            }
            loadCurrentLocation()
        } else if file.isVideo {
            selectedVideoFile = file
        }
    }

    @MainActor
    private func play(_ file: WebDAVFile, on server: WebDAVServer, fromDetails: Bool = false) {
        vm.play(file: file, server: server)
        if fromDetails {
            detailShowingPlayer = vm.nowPlayingURL != nil
        } else {
            showingPlayer = vm.nowPlayingURL != nil
        }
    }

    private func delete(_ file: WebDAVFile, on server: WebDAVServer) {
        Task {
            do {
                let client = WebDAVClient(server: server)
                try await client.delete(file: file)
                if let url = client.streamURL(for: file) {
                    VideoThumbnailLoader.deleteCache(for: url)
                }
                PikPakFolderCoverStore.remove(for: coverKey(for: file, server: server))
                folderCoverVersion &+= 1
                await refreshCurrentLocation()
            } catch {
                vm.errorMessage = error.localizedDescription
            }
        }
    }

    private func updateFolderImmediately(_ update: () -> Void) {
        var transaction = Transaction(animation: nil)
        transaction.disablesAnimations = true
        withTransaction(transaction, update)
    }
    /// A cover belongs to this exact server item, never just a visible name.
    private func coverKey(for file: WebDAVFile, server: WebDAVServer) -> String {
        server.id.uuidString + "|" + (file.isDirectory ? "folder" : "file") + "|" + file.path + "|" + file.name
    }

    private func folderCover(for file: WebDAVFile, server: WebDAVServer) -> UIImage? {
        _ = folderCoverVersion
        return PikPakFolderCoverStore.image(for: coverKey(for: file, server: server))
    }

    /// Folders always allowed; any other file only if size ≥ 500 MB.
    private func meetsMinimumVideoSize(_ file: WebDAVFile) -> Bool {
        if file.isDirectory { return true }
        guard let size = file.size else { return false } // unknown size → hide
        return size >= Self.minimumVideoSizeBytes
    }

    private func visibleFiles(_ source: [WebDAVFile], at current: PikPakLocation) -> [WebDAVFile] {
        let sized = source.filter(meetsMinimumVideoSize)
        guard current.path.isEmpty else { return sized }
        return sized.filter {
            !$0.isDirectory || mainFolderNames.contains($0.name.trimmingCharacters(in: .whitespacesAndNewlines).lowercased())
        }
    }
    private func refreshCurrentLocation() async {
        guard let server else { return }
        let current = location
        isRefreshing = true
        let refreshedFiles = await vm.pikPakFiles(server: server, path: current.path, flattenFolders: current.flattensFolders, extractSmallFolders: current.extractSmallFolders, forceRefresh: true)
        if vm.errorMessage == nil || !refreshedFiles.isEmpty {
            files = visibleFiles(refreshedFiles, at: current)
            scheduleVisiblePosterPrefetch()
        }
        isRefreshing = false
    }
    private func posterRequests(for list: [WebDAVFile], server: WebDAVServer) -> [VideoThumbnailLoader.PrefetchRequest] {
        let client = WebDAVClient(server: server)
        let headers = client.streamHeaders()
        return list.compactMap { file -> VideoThumbnailLoader.PrefetchRequest? in
            guard !file.isDirectory, file.isVideo, meetsMinimumVideoSize(file),
                  let url = client.streamURL(for: file) else { return nil }
            let key = server.id.uuidString + "|file|" + file.path + "|" + file.name
            return VideoThumbnailLoader.PrefetchRequest(
    url: url,
    stableKey: key,
    headers: headers,
    fileExtension: file.fileExtension
)
        }
    }
    private func loadCurrentLocation() {
        guard let server else {
            files = []
            return
        }
        let current = location
        if let cachedFiles = vm.cachedPikPakFiles(server: server, path: current.path, flattenFolders: current.flattensFolders, extractSmallFolders: current.extractSmallFolders) {
            files = visibleFiles(cachedFiles, at: current)
            scheduleVisiblePosterPrefetch()
        } else {
            Task { await refreshCurrentLocation() }
        }
    }
}

private struct PikPakLocation: Identifiable {
    let id = UUID()
    let title: String
    let path: String
    let flattensFolders: Bool
    let extractSmallFolders: Bool
}

private struct PikPakFilePoster: View {
    let file: WebDAVFile
    let server: WebDAVServer
    let posterRefreshVersion: Int
    let folderCover: UIImage?
    let usesMainFolderArtwork: Bool
    let action: () -> Void
    @ObservedObject private var downloadManager = VideoDownloadManager.shared
    @State private var poster: UIImage?
    @State private var isLoadingPoster = false

    private var stableCacheKey: String {
        server.id.uuidString + "|file|" + file.path + "|" + file.name
    }

    private var currentDownload: ManagedVideoDownload? {
        guard !file.isDirectory else { return nil }
        return downloadManager.download(forSourceURL: WebDAVClient(server: server).streamURL(for: file))
    }

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 6) {
                GeometryReader { proxy in
                    ZStack {
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .fill(file.isDirectory ? Color.indigo.opacity(0.45) : Color.white.opacity(0.10))

                        if let folderCover {
                            Image(uiImage: folderCover)
                                .resizable()
                                .scaledToFill()
                                .frame(width: proxy.size.width, height: proxy.size.height)
                                .clipped()
                        } else if usesMainFolderArtwork, PikPakMainFolderArtwork.supports(file.name) {
                            PikPakMainFolderArtwork(name: file.name)
                                .frame(width: proxy.size.width, height: proxy.size.height)
                        } else if let poster {
                            Image(uiImage: poster)
                                .resizable()
                                .scaledToFill()
                                .frame(width: proxy.size.width, height: proxy.size.height)
                                .clipped()
                        } else if !file.isDirectory && isLoadingPoster {
                            ProgressView()
                                .tint(.cyan)
                                .controlSize(.small)
                        } else {
                            Image(systemName: file.isDirectory ? "folder.fill" : "play.rectangle.fill")
                                .font(.system(size: file.isDirectory ? 22 : 24, weight: .medium))
                                .foregroundColor(file.isDirectory ? .yellow : .cyan)
                        }

                        if !file.isDirectory {
                            VStack {
                                HStack {
                                    if !file.sizeFormatted.isEmpty {
                                        Text(file.sizeFormatted)
                                            .font(.system(size: 7, weight: .bold))
                                            .foregroundColor(.white)
                                            .padding(.horizontal, 4)
                                            .padding(.vertical, 3)
                                            .background(Color.black.opacity(0.72), in: Capsule())
                                    }
                                    Spacer()
                                    Text(file.fileExtension)
                                        .font(.system(size: 8, weight: .bold))
                                        .foregroundColor(.white)
                                        .padding(.horizontal, 5)
                                        .padding(.vertical, 3)
                                        .background(Color.black.opacity(0.72), in: Capsule())
                                }
                                Spacer()
                            }
                            .padding(5)
                        }

                        if let currentDownload {
                            VideoDownloadStateOverlay(download: currentDownload, compact: true)
                        }
                    }
                    .frame(width: proxy.size.width, height: proxy.size.height)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .stroke(Color.white.opacity(0.08), lineWidth: 1)
                    )
                    .clipped()
                }
                .aspectRatio(16 / 9, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                .shadow(color: .black.opacity(0.25), radius: 6, y: 3)

                Text(file.displayName)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(.white)
                    .lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .clipped()
        }
        .buttonStyle(.plain)
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
        .clipped()
        .task(id: "\(server.id.uuidString)|\(file.path)|\(posterRefreshVersion)") {
            guard !file.isDirectory, WebDAVClient(server: server).streamURL(for: file) != nil else {
                isLoadingPoster = false
                return
            }
            // 1) Cached poster (previously fetched from ThePornDB)
            if let folderCover {
                poster = folderCover
                isLoadingPoster = false
                return
            }
            if let cached = VideoThumbnailLoader.cachedImage(forStableKey: stableCacheKey) {
                poster = cached
                isLoadingPoster = false
                return
            }

            // 2) ThePornDB is the only automatic poster source — matched by the
            // cleaned-up file title. No video-frame extraction, no manual covers.
            let query = VideoTitleFormatter.title(from: file.name)
            isLoadingPoster = true
            if !query.isEmpty, ThePornDBSettings.hasValidAPIKey,
               let metadata = await VideoThumbnailLoader.fetchThePornDBMetadata(for: query),
               let cover = metadata.coverImage {
                poster = cover
                VideoThumbnailLoader.cacheImage(cover, forStableKey: stableCacheKey)
                PikPakFolderCoverStore.saveIfMissing(cover, for: stableCacheKey)
            }
            isLoadingPoster = false
        }
        .onReceive(NotificationCenter.default.publisher(for: VideoThumbnailLoader.stablePosterDidUpdateNotification)) { notification in
            guard let key = notification.object as? String,
                  key == stableCacheKey,
                  let cached = VideoThumbnailLoader.cachedImage(forStableKey: key) else { return }
            poster = cached
            isLoadingPoster = false
        }
        .onReceive(NotificationCenter.default.publisher(for: VideoThumbnailLoader.posterPrefetchDidFinishNotification)) { notification in
            guard let key = notification.object as? String, key == stableCacheKey else { return }
            if let cached = VideoThumbnailLoader.cachedImage(forStableKey: key) {
                poster = cached
            }
            isLoadingPoster = false
        }
    }
}

private struct PikPakMainFolderArtwork: View {
    let name: String

    static func supports(_ name: String) -> Bool {
        switch normalized(name) {
        case "my pack", "my tiktok", "top", "korean movies", "english series",
             "my upload", "anime", "english movies", "elza", "korean drama":
            return true
        default:
            return false
        }
    }

    var body: some View {
        let folderDesign = design
        ZStack {
            LinearGradient(
                colors: [folderDesign.start, folderDesign.end],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            Circle()
                .fill(Color.white.opacity(0.10))
                .frame(width: 92, height: 92)
                .offset(x: 38, y: -54)

            Circle()
                .fill(Color.black.opacity(0.10))
                .frame(width: 74, height: 74)
                .offset(x: -40, y: 58)

            Image(systemName: folderDesign.symbol)
                .font(.system(size: 62, weight: .bold))
                .foregroundColor(.white.opacity(0.07))
                .rotationEffect(.degrees(-14))
                .offset(x: 25, y: 34)

            VStack(spacing: 8) {
                Spacer()

                ZStack {
                    Circle()
                        .fill(Color.white.opacity(0.17))
                        .frame(width: 48, height: 48)
                    Circle()
                        .stroke(Color.white.opacity(0.32), lineWidth: 1)
                        .frame(width: 48, height: 48)
                    Image(systemName: folderDesign.symbol)
                        .font(.system(size: 23, weight: .semibold))
                        .foregroundColor(.white)
                }

                Text(folderDesign.caption)
                    .font(.system(size: 8, weight: .heavy, design: .rounded))
                    .foregroundColor(.white.opacity(0.94))
                    .tracking(0.8)
                    .lineLimit(1)
                    .minimumScaleFactor(0.65)
                    .padding(.horizontal, 6)

                Spacer()
            }
        }
        .clipped()
    }

    private var design: (symbol: String, caption: String, start: Color, end: Color) {
        switch Self.normalized(name) {
        case "my pack":
            return ("archivebox.fill", "MY PACK", Color(red: 0.18, green: 0.42, blue: 0.96), Color(red: 0.38, green: 0.16, blue: 0.72))
        case "my tiktok":
            return ("music.note", "TIKTOK", Color(red: 0.98, green: 0.18, blue: 0.48), Color(red: 0.02, green: 0.72, blue: 0.82))
        case "top":
            return ("crown.fill", "TOP", Color(red: 0.98, green: 0.68, blue: 0.10), Color(red: 0.92, green: 0.28, blue: 0.08))
        case "korean movies":
            return ("film.fill", "K-MOVIES", Color(red: 0.82, green: 0.10, blue: 0.20), Color(red: 0.28, green: 0.08, blue: 0.42))
        case "english series":
            return ("tv.fill", "SERIES", Color(red: 0.12, green: 0.52, blue: 0.94), Color(red: 0.18, green: 0.12, blue: 0.58))
        case "my upload":
            return ("cloud.fill", "UPLOAD", Color(red: 0.08, green: 0.72, blue: 0.88), Color(red: 0.06, green: 0.28, blue: 0.68))
        case "anime":
            return ("sparkles", "ANIME", Color(red: 0.96, green: 0.26, blue: 0.68), Color(red: 0.42, green: 0.12, blue: 0.78))
        case "english movies":
            return ("film.fill", "MOVIES", Color(red: 0.06, green: 0.68, blue: 0.58), Color(red: 0.06, green: 0.30, blue: 0.62))
        case "elza":
            return ("snowflake", "ELZA", Color(red: 0.48, green: 0.88, blue: 1.00), Color(red: 0.24, green: 0.34, blue: 0.86))
        case "korean drama":
            return ("heart.fill", "K-DRAMA", Color(red: 0.98, green: 0.34, blue: 0.50), Color(red: 0.64, green: 0.08, blue: 0.28))
        default:
            return ("folder.fill", "FOLDER", Color.indigo, Color.purple)
        }
    }

    private static func normalized(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    }
}

private enum PikPakFolderCoverStore {
    private static let mapKey = "pikpak_item_cover_files_v2"
    private static var cachedValues: [String: String]?

    static func image(for path: String) -> UIImage? {
        guard let filename = map()[path] else { return nil }
        return VideoThumbnailLoader.loadCustomPoster(fileName: filename)
    }

    static func save(_ image: UIImage, for path: String) {
        var values = map()
        if let old = values[path] { VideoThumbnailLoader.deleteCustomPoster(fileName: old) }
        guard let filename = VideoThumbnailLoader.saveCustomPoster(image, for: UUID()) else { return }
        values[path] = filename
        saveMap(values)
    }

    static func saveIfMissing(_ image: UIImage, for path: String) {
        var values = map()
        guard values[path] == nil else { return }
        guard let filename = VideoThumbnailLoader.saveCustomPoster(image, for: UUID()) else { return }
        values[path] = filename
        saveMap(values)
    }

    static func remove(for path: String) {
        var values = map()
        if let old = values.removeValue(forKey: path) { VideoThumbnailLoader.deleteCustomPoster(fileName: old) }
        saveMap(values)
    }

    private static func map() -> [String: String] {
        if let cachedValues { return cachedValues }
        guard let data = UserDefaults.standard.data(forKey: mapKey),
              let values = try? JSONDecoder().decode([String: String].self, from: data) else {
            cachedValues = [:]
            return [:]
        }
        cachedValues = values
        return values
    }

    private static func saveMap(_ values: [String: String]) {
        cachedValues = values
        guard let data = try? JSONEncoder().encode(values) else { return }
        UserDefaults.standard.set(data, forKey: mapKey)
    }
}