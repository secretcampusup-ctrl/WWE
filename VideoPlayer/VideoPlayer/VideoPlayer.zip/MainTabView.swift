import SwiftUI
import UIKit
import Kingfisher

/// Root shell: Library, Recent, Offcloud, Media
struct MainTabView: View {
    @StateObject private var vm = AppViewModel()
    @State private var selectedTab = 0
    @State private var pikPakHomeToken = 0

    var body: some View {
        TabView(selection: tabSelection) {
            ContentView(vm: vm, isActive: selectedTab == 0)
                .tabItem {
                    Label("Library", systemImage: "play.rectangle.on.rectangle")
                }
                .tag(0)

            RecentVideosView(vm: vm, isActive: selectedTab == 1)
                .tabItem {
                    Label("Recent", systemImage: "clock.fill")
                }
                .tag(1)

            OffcloudView(vm: vm)
                .tabItem {
                    Label("Offcloud", systemImage: "cloud.fill")
                }
                .tag(2)

            PikPakWebDAVView(vm: vm, homeToken: pikPakHomeToken, isActive: selectedTab == 3)
                .tabItem {
                    Label("PikPak", systemImage: "externaldrive.connected.to.line.below")
                }
                .tag(3)

            MediaView(vm: vm)
                .tabItem {
                    Label("Media", systemImage: "dot.radiowaves.left.and.right")
                }
                .tag(4)
        }
        .transaction { $0.animation = nil }
        .tint(.green)
        .preferredColorScheme(.dark)
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { selectedTab },
            set: { newTab in
                if newTab == 3, selectedTab == 3 {
                    pikPakHomeToken &+= 1
                }
                selectedTab = newTab
            }
        )
    }
}

// MARK: - Shared visual tokens

enum AppTheme {
    static let bg = Color(red: 0.04, green: 0.04, blue: 0.05)
    static let card = Color(red: 0.10, green: 0.10, blue: 0.12)
    static let cardElevated = Color(red: 0.13, green: 0.13, blue: 0.15)
    static let accent = Color.green
    static let accentDeep = Color(red: 0.0, green: 0.55, blue: 0.25)
    static let muted = Color.white.opacity(0.45)
    static let mutedDeep = Color.white.opacity(0.38)

    static let titleGradient = LinearGradient(
        colors: [
            Color(red: 0.85, green: 0.98, blue: 0.92),
            Color(red: 0.55, green: 0.95, blue: 0.75)
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    static let accentGradient = LinearGradient(
        colors: [
            Color.green,
            Color(red: 0.15, green: 0.75, blue: 0.40)
        ],
        startPoint: .leading,
        endPoint: .trailing
    )
}
