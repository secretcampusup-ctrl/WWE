import Foundation
import AVFoundation

/// Downloads an HLS (.m3u8) stream by fetching every segment directly and
/// remuxing them into a single standalone .mp4 file.
///
/// Why not AVAssetDownloadTask? It's Apple's built-in HLS offline API, but it
/// only produces an opaque .movpkg *bundle* meant for in-app AVPlayer
/// playback — it can never be exported/shared as a normal video file. This
/// downloader instead: resolves the playlist, fetches every segment in
/// order, concatenates them into one MPEG-TS file, then uses
/// AVAssetExportSession to remux (not re-encode) that into a real .mp4.
///
/// Limitation: this runs as a Swift Task on the app's own process rather
/// than a background URLSession, so the app needs to stay open (foreground
/// or briefly backgrounded) while a download is in progress.
enum HLSSegmentDownloader {

    enum DownloadError: LocalizedError {
        case invalidPlaylist
        case noSegments
        case encryptedSegments
        case exportFailed(String)

        var errorDescription: String? {
            switch self {
            case .invalidPlaylist: return "تعذّر قراءة قائمة تشغيل HLS"
            case .noSegments: return "ما فيه مقاطع فيديو في هذا الرابط"
            case .encryptedSegments: return "المقاطع مشفّرة (AES) — هذا غير مدعوم حالياً"
            case .exportFailed(let msg): return "فشل تحويل الفيديو إلى mp4: \(msg)"
            }
        }
    }

    struct Progress {
        let downloadedSegments: Int
        let totalSegments: Int
        var fraction: Double {
            totalSegments > 0 ? Double(downloadedSegments) / Double(totalSegments) : 0
        }
    }

    /// Downloads and remuxes an HLS stream to a local .mp4 file.
    /// - Returns: URL of the produced .mp4 in a temp location — caller must
    ///   move it to its final destination (this function cleans up its temp
    ///   working directory once it returns).
    static func download(
        masterURL: URL,
        onProgress: @escaping (Progress) -> Void
    ) async throws -> URL {
        let playlistText = try await fetchText(masterURL)
        let mediaPlaylistURL = try resolveMediaPlaylistURL(masterURL: masterURL, masterPlaylistText: playlistText)
        let mediaPlaylistText = mediaPlaylistURL == masterURL
            ? playlistText
            : try await fetchText(mediaPlaylistURL)

        if mediaPlaylistText.contains("#EXT-X-KEY") && !mediaPlaylistText.contains("METHOD=NONE") {
            throw DownloadError.encryptedSegments
        }

        let segmentURLs = try parseSegmentURLs(playlistText: mediaPlaylistText, baseURL: mediaPlaylistURL)
        guard !segmentURLs.isEmpty else { throw DownloadError.noSegments }

        let tempDir = FileManager.default.temporaryDirectory
            .appendingPathComponent("hls_\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)

        let combinedTSPath = tempDir.appendingPathComponent("combined.ts")
        FileManager.default.createFile(atPath: combinedTSPath.path, contents: nil)
        let handle = try FileHandle(forWritingTo: combinedTSPath)

        var completed = 0
        for segmentURL in segmentURLs {
            try Task.checkCancellation()
            let data = try await fetchData(segmentURL)
            handle.write(data)
            completed += 1
            onProgress(Progress(downloadedSegments: completed, totalSegments: segmentURLs.count))
        }
        try? handle.close()

        let mp4URL = tempDir.appendingPathComponent("output.mp4")
        try await remux(tsFile: combinedTSPath, to: mp4URL)

        // Move the finished mp4 out before the temp working directory is
        // removed, so the caller gets a file that survives cleanup.
        let finalURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("hls_output_\(UUID().uuidString).mp4")
        try FileManager.default.moveItem(at: mp4URL, to: finalURL)
        try? FileManager.default.removeItem(at: tempDir)
        return finalURL
    }

    private static func remux(tsFile: URL, to mp4URL: URL) async throws {
        let asset = AVURLAsset(url: tsFile)
        guard let export = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetPassthrough) else {
            throw DownloadError.exportFailed("presetPassthrough غير مدعوم لهذا المحتوى")
        }
        export.outputURL = mp4URL
        export.outputFileType = .mp4
        await export.export()
        if export.status != .completed {
            throw DownloadError.exportFailed(export.error?.localizedDescription ?? "unknown")
        }
    }

    private static func fetchText(_ url: URL) async throws -> String {
        let (data, response) = try await URLSession.shared.data(from: url)
        try checkAuth(response)
        guard let text = String(data: data, encoding: .utf8) else { throw DownloadError.invalidPlaylist }
        return text
    }

    private static func fetchData(_ url: URL) async throws -> Data {
        let (data, response) = try await URLSession.shared.data(from: url)
        try checkAuth(response)
        return data
    }

    private static func checkAuth(_ response: URLResponse) throws {
        if let http = response as? HTTPURLResponse, http.statusCode == 401 || http.statusCode == 403 {
            throw URLError(.userAuthenticationRequired)
        }
    }

    /// If the given playlist is a master playlist (lists variant streams),
    /// pick the highest-bandwidth variant and return its resolved URL.
    /// Otherwise the given URL already points at a media (segment) playlist.
    private static func resolveMediaPlaylistURL(masterURL: URL, masterPlaylistText: String) throws -> URL {
        let lines = masterPlaylistText.split(separator: "\n", omittingEmptySubsequences: false).map(String.init)
        var bestBandwidth = -1
        var bestURI: String?
        var index = 0
        while index < lines.count {
            let line = lines[index]
            if line.hasPrefix("#EXT-X-STREAM-INF") {
                let bandwidth = extractInt(from: line, key: "BANDWIDTH") ?? 0
                if index + 1 < lines.count {
                    let uriLine = lines[index + 1].trimmingCharacters(in: .whitespacesAndNewlines)
                    if !uriLine.isEmpty, !uriLine.hasPrefix("#"), bandwidth > bestBandwidth {
                        bestBandwidth = bandwidth
                        bestURI = uriLine
                    }
                }
            }
            index += 1
        }
        guard let uri = bestURI else {
            // No variant streams found — this is already a media playlist.
            return masterURL
        }
        return resolve(uri: uri, relativeTo: masterURL)
    }

    private static func parseSegmentURLs(playlistText: String, baseURL: URL) throws -> [URL] {
        let lines = playlistText.split(separator: "\n", omittingEmptySubsequences: false).map(String.init)
        var urls: [URL] = []
        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty, !trimmed.hasPrefix("#") else { continue }
            urls.append(resolve(uri: trimmed, relativeTo: baseURL))
        }
        return urls
    }

    private static func resolve(uri: String, relativeTo base: URL) -> URL {
        if let absolute = URL(string: uri), absolute.scheme != nil {
            return absolute
        }
        return URL(string: uri, relativeTo: base)?.absoluteURL ?? base
    }

    private static func extractInt(from line: String, key: String) -> Int? {
        guard let range = line.range(of: "\(key)=") else { return nil }
        let rest = line[range.upperBound...]
        let digits = rest.prefix { $0.isNumber }
        return Int(digits)
    }
}
